# Type Alias: PikaNetworkLeaderboardResponse

```ts
type PikaNetworkLeaderboardResponse = z.infer<typeof PikaNetworkLeaderboardResponseSchema>;
```
