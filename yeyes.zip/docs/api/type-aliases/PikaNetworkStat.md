# Type Alias: PikaNetworkStat\<G\>

```ts
type PikaNetworkStat<G> = keyof typeof PikaNetworkStats[G];
```

## Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* [`PikaNetworkGamemode`](PikaNetworkGamemode.md) |
