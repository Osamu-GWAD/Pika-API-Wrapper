# Type Alias: BatchResult\<T\>

```ts
type BatchResult<T> = 
  | {
  status: "fulfilled";
  value: T;
}
  | {
  reason: unknown;
  status: "rejected";
};
```

## Type Parameters

| Type Parameter |
| ------ |
| `T` |
