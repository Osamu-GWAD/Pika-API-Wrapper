# Type Alias: PikaNetworkInterval

```ts
type PikaNetworkInterval = typeof PikaNetworkIntervals[number];
```
