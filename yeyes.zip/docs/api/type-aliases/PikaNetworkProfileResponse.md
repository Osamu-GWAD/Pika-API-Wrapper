# Type Alias: PikaNetworkProfileResponse

```ts
type PikaNetworkProfileResponse = z.infer<typeof PikaNetworkProfileResponseSchema>;
```
