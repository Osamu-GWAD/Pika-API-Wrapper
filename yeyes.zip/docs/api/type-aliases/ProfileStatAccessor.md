# Type Alias: ProfileStatAccessor

```ts
type ProfileStatAccessor = { [G in keyof typeof StatKey]: { [K in keyof typeof StatKey[G]]: ProfileStat | null } };
```

provides direct access to profile stats through the `StatKey` hierarchy.
stats that were not fetched or have no recorded value resolve to `null`.
