# Type Alias: ProfileStats

```ts
type ProfileStats = ProfileStat[] & object;
```

profile stats returned as a normal `ProfileStat[]` with an additional
non-enumerable `StatKey` accessor for direct, autocomplete-friendly lookup.

## Type Declaration

### StatKey

```ts
readonly StatKey: ProfileStatAccessor;
```
