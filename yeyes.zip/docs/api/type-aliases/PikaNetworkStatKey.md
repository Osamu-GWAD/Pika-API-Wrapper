# Type Alias: PikaNetworkStatKey\<G\>

```ts
type PikaNetworkStatKey<G> = Exclude<typeof PikaNetworkStats[G][keyof typeof PikaNetworkStats[G]], null>;
```

## Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* [`PikaNetworkGamemode`](PikaNetworkGamemode.md) |
