# Type Alias: PikaNetworkMode\<G\>

```ts
type PikaNetworkMode<G> = typeof PikaNetworkModes[G][number];
```

## Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* [`PikaNetworkGamemode`](PikaNetworkGamemode.md) |
