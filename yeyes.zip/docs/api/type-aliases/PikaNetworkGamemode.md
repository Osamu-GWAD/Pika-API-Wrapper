# Type Alias: PikaNetworkGamemode

```ts
type PikaNetworkGamemode = typeof PikaNetworkGamemodes[number];
```
