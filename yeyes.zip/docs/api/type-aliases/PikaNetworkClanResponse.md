# Type Alias: PikaNetworkClanResponse

```ts
type PikaNetworkClanResponse = z.infer<typeof PikaNetworkClanResponseSchema>;
```
