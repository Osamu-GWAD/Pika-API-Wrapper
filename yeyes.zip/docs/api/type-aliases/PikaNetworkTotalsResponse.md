# Type Alias: PikaNetworkTotalsResponse

```ts
type PikaNetworkTotalsResponse = z.infer<typeof PikaNetworkTotalsResponseSchema>;
```
