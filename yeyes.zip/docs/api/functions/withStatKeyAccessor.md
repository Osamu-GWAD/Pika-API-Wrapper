# Function: withStatKeyAccessor()

```ts
function withStatKeyAccessor(stats: ProfileStat[]): ProfileStats;
```

wraps a raw `ProfileStat[]` with the `.StatKey.<Gamemode>.<Stat>` accessor

## Parameters

| Parameter | Type |
| ------ | ------ |
| `stats` | [`ProfileStat`](../interfaces/ProfileStat.md)[] |

## Returns

[`ProfileStats`](../type-aliases/ProfileStats.md)
