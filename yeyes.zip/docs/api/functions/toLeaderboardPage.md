# Function: toLeaderboardPage()

```ts
function toLeaderboardPage(raw: object): LeaderboardPage;
```

## Parameters

| Parameter | Type |
| ------ | ------ |
| `raw` | \{ `entries`: `object`[] \| `null`; `metadata`: \{ `total`: `number`; \}; \} |
| `raw.entries` | `object`[] \| `null` |
| `raw.metadata` | \{ `total`: `number`; \} |
| `raw.metadata.total` | `number` |

## Returns

[`LeaderboardPage`](../interfaces/LeaderboardPage.md)
