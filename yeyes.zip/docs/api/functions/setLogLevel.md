# Function: setLogLevel()

```ts
function setLogLevel(level: "silent" | "warn" | "info" | "debug"): void;
```

## Parameters

| Parameter | Type |
| ------ | ------ |
| `level` | `"silent"` \| `"warn"` \| `"info"` \| `"debug"` |

## Returns

`void`
