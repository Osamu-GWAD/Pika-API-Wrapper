# Class: NetworkHTTPError

a generic HTTP failure (405/500/502/503/504/etc.) that isn't one of the
more specific cases below.

entity-not-found responses are handled separately and resolve to `null`.
see the client docs.

## Extends

- [`NetworkAPIError`](NetworkAPIError.md)

## Constructors

### Constructor

```ts
new NetworkHTTPError(
   network: string, 
   message: string, 
   options?: object): NetworkHTTPError;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `network` | `string` |
| `message` | `string` |
| `options` | \{ `cause?`: `unknown`; `status?`: `number`; `url?`: `string`; \} |
| `options.cause?` | `unknown` |
| `options.status?` | `number` |
| `options.url?` | `string` |

#### Returns

`NetworkHTTPError`

#### Inherited from

[`NetworkAPIError`](NetworkAPIError.md).[`constructor`](NetworkAPIError.md#constructor)

## Properties

| Property | Modifier | Type | Inherited from |
| ------ | ------ | ------ | ------ |
| <a id="network"></a> `network` | `readonly` | `string` | [`NetworkAPIError`](NetworkAPIError.md).[`network`](NetworkAPIError.md#network) |
| <a id="status"></a> `status` | `readonly` | `number` \| `undefined` | [`NetworkAPIError`](NetworkAPIError.md).[`status`](NetworkAPIError.md#status) |
| <a id="url"></a> `url?` | `readonly` | `string` | [`NetworkAPIError`](NetworkAPIError.md).[`url`](NetworkAPIError.md#url) |
