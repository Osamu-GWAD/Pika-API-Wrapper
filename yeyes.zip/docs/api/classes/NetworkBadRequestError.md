# Class: NetworkBadRequestError

indicates a malformed request.

e.g. invalid gamemode/mode/stat/interval combination, missing param, etc.
HTTP 400

## Extends

- [`NetworkAPIError`](NetworkAPIError.md)

## Constructors

### Constructor

```ts
new NetworkBadRequestError(
   network: string, 
   message: string, 
   options?: object): NetworkBadRequestError;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `network` | `string` |
| `message` | `string` |
| `options` | \{ `cause?`: `unknown`; `url?`: `string`; \} |
| `options.cause?` | `unknown` |
| `options.url?` | `string` |

#### Returns

`NetworkBadRequestError`

#### Overrides

[`NetworkAPIError`](NetworkAPIError.md).[`constructor`](NetworkAPIError.md#constructor)

## Properties

| Property | Modifier | Type | Inherited from |
| ------ | ------ | ------ | ------ |
| <a id="network"></a> `network` | `readonly` | `string` | [`NetworkAPIError`](NetworkAPIError.md).[`network`](NetworkAPIError.md#network) |
| <a id="status"></a> `status` | `readonly` | `number` \| `undefined` | [`NetworkAPIError`](NetworkAPIError.md).[`status`](NetworkAPIError.md#status) |
| <a id="url"></a> `url?` | `readonly` | `string` | [`NetworkAPIError`](NetworkAPIError.md).[`url`](NetworkAPIError.md#url) |
