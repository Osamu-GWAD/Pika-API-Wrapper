# Class: KeyvCache

uses keyv's in-memory adapter by default.
pass a persistent adapter such as @keyv/redis for shared or persistent caching.

## Implements

- [`NetworkCache`](../interfaces/NetworkCache.md)

## Constructors

### Constructor

```ts
new KeyvCache(keyv?: Keyv): KeyvCache;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `keyv` | `Keyv` |

#### Returns

`KeyvCache`

## Methods

### clear()

```ts
clear(): Promise<void>;
```

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`NetworkCache`](../interfaces/NetworkCache.md).[`clear`](../interfaces/NetworkCache.md#clear)

***

### delete()

```ts
delete(key: string): Promise<void>;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `key` | `string` |

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`NetworkCache`](../interfaces/NetworkCache.md).[`delete`](../interfaces/NetworkCache.md#delete)

***

### get()

```ts
get<T>(key: string): Promise<T | undefined>;
```

#### Type Parameters

| Type Parameter |
| ------ |
| `T` |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `key` | `string` |

#### Returns

`Promise`\<`T` \| `undefined`\>

#### Implementation of

[`NetworkCache`](../interfaces/NetworkCache.md).[`get`](../interfaces/NetworkCache.md#get)

***

### set()

```ts
set<T>(
   key: string, 
   value: T, 
ttlMs?: number): Promise<void>;
```

#### Type Parameters

| Type Parameter |
| ------ |
| `T` |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `key` | `string` |
| `value` | `T` |
| `ttlMs?` | `number` |

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`NetworkCache`](../interfaces/NetworkCache.md).[`set`](../interfaces/NetworkCache.md#set)
