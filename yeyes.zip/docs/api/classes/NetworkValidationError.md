# Class: NetworkValidationError

indicates that the response does not conform to the expected schema.

typically indicates an upstream response shape change or unexpected payload.
it shouldn't happen, but- CraftiGames~

## Extends

- [`NetworkAPIError`](NetworkAPIError.md)

## Constructors

### Constructor

```ts
new NetworkValidationError(
   network: string, 
   message: string, 
   options?: object): NetworkValidationError;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `network` | `string` |
| `message` | `string` |
| `options` | \{ `cause?`: `unknown`; `issues?`: `unknown`; `url?`: `string`; \} |
| `options.cause?` | `unknown` |
| `options.issues?` | `unknown` |
| `options.url?` | `string` |

#### Returns

`NetworkValidationError`

#### Overrides

[`NetworkAPIError`](NetworkAPIError.md).[`constructor`](NetworkAPIError.md#constructor)

## Properties

| Property | Modifier | Type | Inherited from |
| ------ | ------ | ------ | ------ |
| <a id="issues"></a> `issues` | `readonly` | `unknown` | - |
| <a id="network"></a> `network` | `readonly` | `string` | [`NetworkAPIError`](NetworkAPIError.md).[`network`](NetworkAPIError.md#network) |
| <a id="status"></a> `status` | `readonly` | `number` \| `undefined` | [`NetworkAPIError`](NetworkAPIError.md).[`status`](NetworkAPIError.md#status) |
| <a id="url"></a> `url?` | `readonly` | `string` | [`NetworkAPIError`](NetworkAPIError.md).[`url`](NetworkAPIError.md#url) |
