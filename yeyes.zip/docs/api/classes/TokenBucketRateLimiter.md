# Class: TokenBucketRateLimiter

## Constructors

### Constructor

```ts
new TokenBucketRateLimiter(options?: RateLimiterOptions): TokenBucketRateLimiter;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `options` | [`RateLimiterOptions`](../interfaces/RateLimiterOptions.md) |

#### Returns

`TokenBucketRateLimiter`

## Methods

### acquire()

```ts
acquire(): Promise<void>;
```

resolves once a token is available, consuming it

#### Returns

`Promise`\<`void`\>

***

### onRateLimited()

```ts
onRateLimited(): void;
```

halves the rate and drains the bucket

called on 429 so the subsequent requests therefore back off
instead of trying at the same pace.

#### Returns

`void`
