# Class: PikaNetworkClient

typed, runtime-validated client

## Extends

- `PikaNetworkFeatureSet`

## Constructors

### Constructor

```ts
new PikaNetworkClient(options?: PikaNetworkClientOptions): PikaNetworkClient;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `options` | [`PikaNetworkClientOptions`](../interfaces/PikaNetworkClientOptions.md) |

#### Returns

`PikaNetworkClient`

#### Overrides

```ts
PikaNetworkFeatureSet.constructor
```

## Methods

### batch()

```ts
batch<T>(operations: T, options?: BatchOptions): Promise<{ [K in string | number | symbol]: BatchResult<Awaited<ReturnType<T[K]>>> }>;
```

executes operations with bounded concurrency

default: 10; override via `batchConcurrency` or per-call `concurrency`.

every operation still goes through the same rate limiter as a single call.
refer to the batch requests guide for the full contract.

#### Type Parameters

| Type Parameter |
| ------ |
| `T` *extends* readonly () => `Promise`\<`unknown`\>[] |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `operations` | `T` |
| `options?` | [`BatchOptions`](../interfaces/BatchOptions.md) |

#### Returns

`Promise`\<\{ \[K in string \| number \| symbol\]: BatchResult\<Awaited\<ReturnType\<T\[K\]\>\>\> \}\>

#### Inherited from

```ts
PikaNetworkFeatureSet.batch
```

***

### getClan()

```ts
getClan(clanName: string, config?: RequestConfig): Promise<
  | objectOutputType<{
  createdAt: ZodOptional<ZodNumber>;
  members: ZodOptional<ZodArray<ZodUnknown, "many">>;
  name: ZodOptional<ZodString>;
  tag: ZodOptional<ZodString>;
  trophies: ZodOptional<ZodNumber>;
}, ZodTypeAny, "passthrough">
| null>;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `clanName` | `string` |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |

#### Returns

`Promise`\<
  \| `objectOutputType`\<\{
  `createdAt`: `ZodOptional`\<`ZodNumber`\>;
  `members`: `ZodOptional`\<`ZodArray`\<`ZodUnknown`, `"many"`\>\>;
  `name`: `ZodOptional`\<`ZodString`\>;
  `tag`: `ZodOptional`\<`ZodString`\>;
  `trophies`: `ZodOptional`\<`ZodNumber`\>;
\}, `ZodTypeAny`, `"passthrough"`\>
  \| `null`\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getClan
```

***

### getClans()

```ts
getClans(
   clanNames: string[], 
   config?: RequestConfig, 
   options?: BatchOptions): Promise<BatchResult<
  | objectOutputType<{
  createdAt: ZodOptional<ZodNumber>;
  members: ZodOptional<ZodArray<ZodUnknown, "many">>;
  name: ZodOptional<ZodString>;
  tag: ZodOptional<ZodString>;
  trophies: ZodOptional<ZodNumber>;
}, ZodTypeAny, "passthrough">
| null>[]>;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `clanNames` | `string`[] |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |
| `options?` | [`BatchOptions`](../interfaces/BatchOptions.md) |

#### Returns

`Promise`\<[`BatchResult`](../type-aliases/BatchResult.md)\<
  \| `objectOutputType`\<\{
  `createdAt`: `ZodOptional`\<`ZodNumber`\>;
  `members`: `ZodOptional`\<`ZodArray`\<`ZodUnknown`, `"many"`\>\>;
  `name`: `ZodOptional`\<`ZodString`\>;
  `tag`: `ZodOptional`\<`ZodString`\>;
  `trophies`: `ZodOptional`\<`ZodNumber`\>;
\}, `ZodTypeAny`, `"passthrough"`\>
  \| `null`\>[]\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getClans
```

***

### getLeaderboard()

```ts
getLeaderboard<G>(parameters: GetLeaderboardParams<G>, config?: RequestConfig): Promise<LeaderboardPage>;
```

#### Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* \| `"bedwars"` \| `"dungeons"` \| `"genpvp"` \| `"kitpvp"` \| `"oneblock"` \| `"opfactions"` \| `"oplifesteal"` \| `"opprison"` \| `"opskyblock"` \| `"pillars"` \| `"skymines"` \| `"skypvp"` \| `"survival"` \| `"unrankedpractice"` |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `parameters` | [`GetLeaderboardParams`](../interfaces/GetLeaderboardParams.md)\<`G`\> |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |

#### Returns

`Promise`\<[`LeaderboardPage`](../interfaces/LeaderboardPage.md)\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getLeaderboard
```

***

### getLeaderboards()

```ts
getLeaderboards<G>(
   requests: GetLeaderboardParams<G>[], 
   config?: RequestConfig, 
options?: BatchOptions): Promise<BatchResult<LeaderboardPage>[]>;
```

#### Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* \| `"bedwars"` \| `"dungeons"` \| `"genpvp"` \| `"kitpvp"` \| `"oneblock"` \| `"opfactions"` \| `"oplifesteal"` \| `"opprison"` \| `"opskyblock"` \| `"pillars"` \| `"skymines"` \| `"skypvp"` \| `"survival"` \| `"unrankedpractice"` |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `requests` | [`GetLeaderboardParams`](../interfaces/GetLeaderboardParams.md)\<`G`\>[] |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |
| `options?` | [`BatchOptions`](../interfaces/BatchOptions.md) |

#### Returns

`Promise`\<[`BatchResult`](../type-aliases/BatchResult.md)\<[`LeaderboardPage`](../interfaces/LeaderboardPage.md)\>[]\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getLeaderboards
```

***

### getMatchRecap()

```ts
getMatchRecap(gameId: string, config?: RequestConfig): Promise<Record<string, unknown> | null>;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `gameId` | `string` |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |

#### Returns

`Promise`\<`Record`\<`string`, `unknown`\> \| `null`\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getMatchRecap
```

***

### getProfile()

```ts
getProfile(username: string, config?: RequestConfig): Promise<
  | objectOutputType<{
  boosting: ZodOptional<ZodBoolean>;
  clan: ZodOptional<ZodNullable<ZodObject<{
     name: ZodOptional<ZodString>;
     tag: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     name?: string;
     tag?: string;
   }, {
     name?: string;
     tag?: string;
  }>>>;
  discord_boosting: ZodOptional<ZodBoolean>;
  discord_verified: ZodOptional<ZodBoolean>;
  email_verified: ZodOptional<ZodBoolean>;
  friends: ZodOptional<ZodArray<ZodUnknown, "many">>;
  lastSeen: ZodOptional<ZodNumber>;
  rank: ZodOptional<ZodObject<{
     experience: ZodOptional<ZodNumber>;
     level: ZodOptional<ZodNumber>;
     percentage: ZodOptional<ZodNumber>;
     rankDisplay: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     experience?: number;
     level?: number;
     percentage?: number;
     rankDisplay?: string;
   }, {
     experience?: number;
     level?: number;
     percentage?: number;
     rankDisplay?: string;
  }>>;
  ranks: ZodOptional<ZodArray<ZodObject<{
     displayName: ZodOptional<ZodString>;
     expiry: ZodOptional<ZodNumber>;
     name: ZodOptional<ZodString>;
     season: ZodOptional<ZodNullable<ZodString>>;
     server: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     displayName?: string;
     expiry?: number;
     name?: string;
     season?: string | null;
     server?: string;
   }, {
     displayName?: string;
     expiry?: number;
     name?: string;
     season?: string | null;
     server?: string;
  }>, "many">>;
  username: ZodOptional<ZodString>;
}, ZodTypeAny, "passthrough">
| null>;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `username` | `string` |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |

#### Returns

`Promise`\<
  \| `objectOutputType`\<\{
  `boosting`: `ZodOptional`\<`ZodBoolean`\>;
  `clan`: `ZodOptional`\<`ZodNullable`\<`ZodObject`\<\{
     `name`: `ZodOptional`\<`ZodString`\>;
     `tag`: `ZodOptional`\<`ZodString`\>;
   \}, `"strip"`, `ZodTypeAny`, \{
     `name?`: `string`;
     `tag?`: `string`;
   \}, \{
     `name?`: `string`;
     `tag?`: `string`;
  \}\>\>\>;
  `discord_boosting`: `ZodOptional`\<`ZodBoolean`\>;
  `discord_verified`: `ZodOptional`\<`ZodBoolean`\>;
  `email_verified`: `ZodOptional`\<`ZodBoolean`\>;
  `friends`: `ZodOptional`\<`ZodArray`\<`ZodUnknown`, `"many"`\>\>;
  `lastSeen`: `ZodOptional`\<`ZodNumber`\>;
  `rank`: `ZodOptional`\<`ZodObject`\<\{
     `experience`: `ZodOptional`\<`ZodNumber`\>;
     `level`: `ZodOptional`\<`ZodNumber`\>;
     `percentage`: `ZodOptional`\<`ZodNumber`\>;
     `rankDisplay`: `ZodOptional`\<`ZodString`\>;
   \}, `"strip"`, `ZodTypeAny`, \{
     `experience?`: `number`;
     `level?`: `number`;
     `percentage?`: `number`;
     `rankDisplay?`: `string`;
   \}, \{
     `experience?`: `number`;
     `level?`: `number`;
     `percentage?`: `number`;
     `rankDisplay?`: `string`;
  \}\>\>;
  `ranks`: `ZodOptional`\<`ZodArray`\<`ZodObject`\<\{
     `displayName`: `ZodOptional`\<`ZodString`\>;
     `expiry`: `ZodOptional`\<`ZodNumber`\>;
     `name`: `ZodOptional`\<`ZodString`\>;
     `season`: `ZodOptional`\<`ZodNullable`\<`ZodString`\>\>;
     `server`: `ZodOptional`\<`ZodString`\>;
   \}, `"strip"`, `ZodTypeAny`, \{
     `displayName?`: `string`;
     `expiry?`: `number`;
     `name?`: `string`;
     `season?`: `string` \| `null`;
     `server?`: `string`;
   \}, \{
     `displayName?`: `string`;
     `expiry?`: `number`;
     `name?`: `string`;
     `season?`: `string` \| `null`;
     `server?`: `string`;
  \}\>, `"many"`\>\>;
  `username`: `ZodOptional`\<`ZodString`\>;
\}, `ZodTypeAny`, `"passthrough"`\>
  \| `null`\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getProfile
```

***

### getProfiles()

```ts
getProfiles(
   usernames: string[], 
   config?: RequestConfig, 
   options?: BatchOptions): Promise<BatchResult<
  | objectOutputType<{
  boosting: ZodOptional<ZodBoolean>;
  clan: ZodOptional<ZodNullable<ZodObject<{
     name: ZodOptional<...>;
     tag: ZodOptional<...>;
   }, "strip", ZodTypeAny, {
     name?: ... | ...;
     tag?: ... | ...;
   }, {
     name?: ... | ...;
     tag?: ... | ...;
  }>>>;
  discord_boosting: ZodOptional<ZodBoolean>;
  discord_verified: ZodOptional<ZodBoolean>;
  email_verified: ZodOptional<ZodBoolean>;
  friends: ZodOptional<ZodArray<ZodUnknown, "many">>;
  lastSeen: ZodOptional<ZodNumber>;
  rank: ZodOptional<ZodObject<{
     experience: ZodOptional<ZodNumber>;
     level: ZodOptional<ZodNumber>;
     percentage: ZodOptional<ZodNumber>;
     rankDisplay: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     experience?: number;
     level?: number;
     percentage?: number;
     rankDisplay?: string;
   }, {
     experience?: number;
     level?: number;
     percentage?: number;
     rankDisplay?: string;
  }>>;
  ranks: ZodOptional<ZodArray<ZodObject<{
     displayName: ZodOptional<...>;
     expiry: ZodOptional<...>;
     name: ZodOptional<...>;
     season: ZodOptional<...>;
     server: ZodOptional<...>;
   }, "strip", ZodTypeAny, {
     displayName?: ... | ...;
     expiry?: ... | ...;
     name?: ... | ...;
     season?: ... | ... | ...;
     server?: ... | ...;
   }, {
     displayName?: ... | ...;
     expiry?: ... | ...;
     name?: ... | ...;
     season?: ... | ... | ...;
     server?: ... | ...;
  }>, "many">>;
  username: ZodOptional<ZodString>;
}, ZodTypeAny, "passthrough">
| null>[]>;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `usernames` | `string`[] |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |
| `options?` | [`BatchOptions`](../interfaces/BatchOptions.md) |

#### Returns

`Promise`\<[`BatchResult`](../type-aliases/BatchResult.md)\<
  \| `objectOutputType`\<\{
  `boosting`: `ZodOptional`\<`ZodBoolean`\>;
  `clan`: `ZodOptional`\<`ZodNullable`\<`ZodObject`\<\{
     `name`: `ZodOptional`\<...\>;
     `tag`: `ZodOptional`\<...\>;
   \}, `"strip"`, `ZodTypeAny`, \{
     `name?`: ... \| ...;
     `tag?`: ... \| ...;
   \}, \{
     `name?`: ... \| ...;
     `tag?`: ... \| ...;
  \}\>\>\>;
  `discord_boosting`: `ZodOptional`\<`ZodBoolean`\>;
  `discord_verified`: `ZodOptional`\<`ZodBoolean`\>;
  `email_verified`: `ZodOptional`\<`ZodBoolean`\>;
  `friends`: `ZodOptional`\<`ZodArray`\<`ZodUnknown`, `"many"`\>\>;
  `lastSeen`: `ZodOptional`\<`ZodNumber`\>;
  `rank`: `ZodOptional`\<`ZodObject`\<\{
     `experience`: `ZodOptional`\<`ZodNumber`\>;
     `level`: `ZodOptional`\<`ZodNumber`\>;
     `percentage`: `ZodOptional`\<`ZodNumber`\>;
     `rankDisplay`: `ZodOptional`\<`ZodString`\>;
   \}, `"strip"`, `ZodTypeAny`, \{
     `experience?`: `number`;
     `level?`: `number`;
     `percentage?`: `number`;
     `rankDisplay?`: `string`;
   \}, \{
     `experience?`: `number`;
     `level?`: `number`;
     `percentage?`: `number`;
     `rankDisplay?`: `string`;
  \}\>\>;
  `ranks`: `ZodOptional`\<`ZodArray`\<`ZodObject`\<\{
     `displayName`: `ZodOptional`\<...\>;
     `expiry`: `ZodOptional`\<...\>;
     `name`: `ZodOptional`\<...\>;
     `season`: `ZodOptional`\<...\>;
     `server`: `ZodOptional`\<...\>;
   \}, `"strip"`, `ZodTypeAny`, \{
     `displayName?`: ... \| ...;
     `expiry?`: ... \| ...;
     `name?`: ... \| ...;
     `season?`: ... \| ... \| ...;
     `server?`: ... \| ...;
   \}, \{
     `displayName?`: ... \| ...;
     `expiry?`: ... \| ...;
     `name?`: ... \| ...;
     `season?`: ... \| ... \| ...;
     `server?`: ... \| ...;
  \}\>, `"many"`\>\>;
  `username`: `ZodOptional`\<`ZodString`\>;
\}, `ZodTypeAny`, `"passthrough"`\>
  \| `null`\>[]\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getProfiles
```

***

### getProfileStat()

```ts
getProfileStat<G>(
   parameters: GetProfileStatsParams<G>, 
   statKey: PikaNetworkStatKey<G>, 
config?: RequestConfig): Promise<ProfileStat | null>;
```

#### Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* \| `"bedwars"` \| `"dungeons"` \| `"genpvp"` \| `"kitpvp"` \| `"oneblock"` \| `"opfactions"` \| `"oplifesteal"` \| `"opprison"` \| `"opskyblock"` \| `"pillars"` \| `"skymines"` \| `"skypvp"` \| `"survival"` \| `"unrankedpractice"` |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `parameters` | [`GetProfileStatsParams`](../interfaces/GetProfileStatsParams.md)\<`G`\> |
| `statKey` | [`PikaNetworkStatKey`](../type-aliases/PikaNetworkStatKey.md)\<`G`\> |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |

#### Returns

`Promise`\<[`ProfileStat`](../interfaces/ProfileStat.md) \| `null`\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getProfileStat
```

***

### getProfileStats()

```ts
getProfileStats<G>(parameters: GetProfileStatsParams<G>, config?: RequestConfig): Promise<ProfileStats>;
```

#### Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* \| `"bedwars"` \| `"dungeons"` \| `"genpvp"` \| `"kitpvp"` \| `"oneblock"` \| `"opfactions"` \| `"oplifesteal"` \| `"opprison"` \| `"opskyblock"` \| `"pillars"` \| `"skymines"` \| `"skypvp"` \| `"survival"` \| `"unrankedpractice"` |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `parameters` | [`GetProfileStatsParams`](../interfaces/GetProfileStatsParams.md)\<`G`\> |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |

#### Returns

`Promise`\<[`ProfileStats`](../type-aliases/ProfileStats.md)\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getProfileStats
```

***

### getProfileStatsBatch()

```ts
getProfileStatsBatch<G>(
   requests: GetProfileStatsParams<G>[], 
   config?: RequestConfig, 
options?: BatchOptions): Promise<BatchResult<ProfileStats>[]>;
```

#### Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* \| `"bedwars"` \| `"dungeons"` \| `"genpvp"` \| `"kitpvp"` \| `"oneblock"` \| `"opfactions"` \| `"oplifesteal"` \| `"opprison"` \| `"opskyblock"` \| `"pillars"` \| `"skymines"` \| `"skypvp"` \| `"survival"` \| `"unrankedpractice"` |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `requests` | [`GetProfileStatsParams`](../interfaces/GetProfileStatsParams.md)\<`G`\>[] |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |
| `options?` | [`BatchOptions`](../interfaces/BatchOptions.md) |

#### Returns

`Promise`\<[`BatchResult`](../type-aliases/BatchResult.md)\<[`ProfileStats`](../type-aliases/ProfileStats.md)\>[]\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getProfileStatsBatch
```

***

### getTotals()

```ts
getTotals<G>(parameters: GetTotalsParams<G>, config?: RequestConfig): Promise<object[]>;
```

#### Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* \| `"bedwars"` \| `"dungeons"` \| `"genpvp"` \| `"kitpvp"` \| `"oneblock"` \| `"opfactions"` \| `"oplifesteal"` \| `"opprison"` \| `"opskyblock"` \| `"pillars"` \| `"skymines"` \| `"skypvp"` \| `"survival"` \| `"unrankedpractice"` |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `parameters` | [`GetTotalsParams`](../interfaces/GetTotalsParams.md)\<`G`\> |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |

#### Returns

`Promise`\<`object`[]\>

#### Inherited from

```ts
PikaNetworkFeatureSet.getTotals
```

***

### ping()

```ts
ping(config?: RequestConfig): Promise<boolean>;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `config?` | [`RequestConfig`](../interfaces/RequestConfig.md) |

#### Returns

`Promise`\<`boolean`\>

#### Inherited from

```ts
PikaNetworkFeatureSet.ping
```
