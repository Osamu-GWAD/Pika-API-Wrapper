# Class: NetworkRateLimitError

indicates that the upstream API is rate-limiting requests (HTTP 429).
back off!

built-in rate limiter tries to prevent this from ever firing.

## Extends

- [`NetworkAPIError`](NetworkAPIError.md)

## Constructors

### Constructor

```ts
new NetworkRateLimitError(
   network: string, 
   message: string, 
   options?: object): NetworkRateLimitError;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `network` | `string` |
| `message` | `string` |
| `options` | \{ `cause?`: `unknown`; `retryAfterMs?`: `number`; `url?`: `string`; \} |
| `options.cause?` | `unknown` |
| `options.retryAfterMs?` | `number` |
| `options.url?` | `string` |

#### Returns

`NetworkRateLimitError`

#### Overrides

[`NetworkAPIError`](NetworkAPIError.md).[`constructor`](NetworkAPIError.md#constructor)

## Properties

| Property | Modifier | Type | Inherited from |
| ------ | ------ | ------ | ------ |
| <a id="network"></a> `network` | `readonly` | `string` | [`NetworkAPIError`](NetworkAPIError.md).[`network`](NetworkAPIError.md#network) |
| <a id="retryafterms"></a> `retryAfterMs` | `readonly` | `number` \| `undefined` | - |
| <a id="status"></a> `status` | `readonly` | `number` \| `undefined` | [`NetworkAPIError`](NetworkAPIError.md).[`status`](NetworkAPIError.md#status) |
| <a id="url"></a> `url?` | `readonly` | `string` | [`NetworkAPIError`](NetworkAPIError.md).[`url`](NetworkAPIError.md#url) |
