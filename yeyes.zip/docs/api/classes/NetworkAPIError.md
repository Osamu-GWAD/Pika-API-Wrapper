# Class: NetworkAPIError

base error for failures raised by a network stats API client

`network` identifies the backend that produced the error, allowing callers
to distinguish failures when handling multiple network clients.

## Extends

- `Error`

## Extended by

- [`NetworkAuthExhaustedError`](NetworkAuthExhaustedError.md)
- [`NetworkBadRequestError`](NetworkBadRequestError.md)
- [`NetworkHTTPError`](NetworkHTTPError.md)
- [`NetworkRateLimitError`](NetworkRateLimitError.md)
- [`NetworkValidationError`](NetworkValidationError.md)

## Constructors

### Constructor

```ts
new NetworkAPIError(
   network: string, 
   message: string, 
   options?: object): NetworkAPIError;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `network` | `string` |
| `message` | `string` |
| `options` | \{ `cause?`: `unknown`; `status?`: `number`; `url?`: `string`; \} |
| `options.cause?` | `unknown` |
| `options.status?` | `number` |
| `options.url?` | `string` |

#### Returns

`NetworkAPIError`

#### Overrides

```ts
Error.constructor
```

## Properties

| Property | Modifier | Type |
| ------ | ------ | ------ |
| <a id="network"></a> `network` | `readonly` | `string` |
| <a id="status"></a> `status` | `readonly` | `number` \| `undefined` |
| <a id="url"></a> `url?` | `readonly` | `string` |
