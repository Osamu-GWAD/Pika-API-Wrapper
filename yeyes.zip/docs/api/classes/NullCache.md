# Class: NullCache

no-op cache for callers who want caching disabled entirely

## Implements

- [`NetworkCache`](../interfaces/NetworkCache.md)

## Constructors

### Constructor

```ts
new NullCache(): NullCache;
```

#### Returns

`NullCache`

## Methods

### clear()

```ts
clear(): Promise<void>;
```

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`NetworkCache`](../interfaces/NetworkCache.md).[`clear`](../interfaces/NetworkCache.md#clear)

***

### delete()

```ts
delete(): Promise<void>;
```

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`NetworkCache`](../interfaces/NetworkCache.md).[`delete`](../interfaces/NetworkCache.md#delete)

***

### get()

```ts
get(): Promise<undefined>;
```

#### Returns

`Promise`\<`undefined`\>

#### Implementation of

[`NetworkCache`](../interfaces/NetworkCache.md).[`get`](../interfaces/NetworkCache.md#get)

***

### set()

```ts
set(): Promise<void>;
```

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`NetworkCache`](../interfaces/NetworkCache.md).[`set`](../interfaces/NetworkCache.md#set)
