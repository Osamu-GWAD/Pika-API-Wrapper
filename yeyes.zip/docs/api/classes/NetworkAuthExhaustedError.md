# Class: NetworkAuthExhaustedError

indicates that all configured API credentials have been exhausted.

reserved for networks that require authentication.

## Extends

- [`NetworkAPIError`](NetworkAPIError.md)

## Constructors

### Constructor

```ts
new NetworkAuthExhaustedError(
   network: string, 
   message: string, 
   options?: object): NetworkAuthExhaustedError;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `network` | `string` |
| `message` | `string` |
| `options` | \{ `cause?`: `unknown`; `status?`: `number`; `url?`: `string`; \} |
| `options.cause?` | `unknown` |
| `options.status?` | `number` |
| `options.url?` | `string` |

#### Returns

`NetworkAuthExhaustedError`

#### Inherited from

[`NetworkAPIError`](NetworkAPIError.md).[`constructor`](NetworkAPIError.md#constructor)

## Properties

| Property | Modifier | Type | Inherited from |
| ------ | ------ | ------ | ------ |
| <a id="network"></a> `network` | `readonly` | `string` | [`NetworkAPIError`](NetworkAPIError.md).[`network`](NetworkAPIError.md#network) |
| <a id="status"></a> `status` | `readonly` | `number` \| `undefined` | [`NetworkAPIError`](NetworkAPIError.md).[`status`](NetworkAPIError.md#status) |
| <a id="url"></a> `url?` | `readonly` | `string` | [`NetworkAPIError`](NetworkAPIError.md).[`url`](NetworkAPIError.md#url) |
