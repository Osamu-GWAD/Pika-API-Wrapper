# Abstract Class: NetworkClient

shared foundation for per-network clients

owns http transport, caching, rate limiting, and batching.
subclasses supply `networkName`/`baseUrl`
and their own endpoint methods on top of `fetchAndValidate`.

## Constructors

### Constructor

```ts
new NetworkClient(options?: NetworkClientOptions): NetworkClient;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `options` | [`NetworkClientOptions`](../interfaces/NetworkClientOptions.md) |

#### Returns

`NetworkClient`

## Methods

### batch()

```ts
batch<T>(operations: T, options?: BatchOptions): Promise<{ [K in string | number | symbol]: BatchResult<Awaited<ReturnType<T[K]>>> }>;
```

executes operations with bounded concurrency

default: 10; override via `batchConcurrency` or per-call `concurrency`.

every operation still goes through the same rate limiter as a single call.
refer to the batch requests guide for the full contract.

#### Type Parameters

| Type Parameter |
| ------ |
| `T` *extends* readonly () => `Promise`\<`unknown`\>[] |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `operations` | `T` |
| `options?` | [`BatchOptions`](../interfaces/BatchOptions.md) |

#### Returns

`Promise`\<\{ \[K in string \| number \| symbol\]: BatchResult\<Awaited\<ReturnType\<T\[K\]\>\>\> \}\>
