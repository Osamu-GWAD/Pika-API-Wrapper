# API Reference

## Classes

| Class | Description |
| ------ | ------ |
| [KeyvCache](classes/KeyvCache.md) | uses keyv's in-memory adapter by default. pass a persistent adapter such as @keyv/redis for shared or persistent caching. |
| [NetworkAPIError](classes/NetworkAPIError.md) | base error for failures raised by a network stats API client |
| [NetworkAuthExhaustedError](classes/NetworkAuthExhaustedError.md) | indicates that all configured API credentials have been exhausted. |
| [NetworkBadRequestError](classes/NetworkBadRequestError.md) | indicates a malformed request. |
| [NetworkClient](classes/NetworkClient.md) | shared foundation for per-network clients |
| [NetworkHTTPError](classes/NetworkHTTPError.md) | a generic HTTP failure (405/500/502/503/504/etc.) that isn't one of the more specific cases below. |
| [NetworkRateLimitError](classes/NetworkRateLimitError.md) | indicates that the upstream API is rate-limiting requests (HTTP 429). back off! |
| [NetworkValidationError](classes/NetworkValidationError.md) | indicates that the response does not conform to the expected schema. |
| [NullCache](classes/NullCache.md) | no-op cache for callers who want caching disabled entirely |
| [PikaNetworkClient](classes/PikaNetworkClient.md) | typed, runtime-validated client |
| [TokenBucketRateLimiter](classes/TokenBucketRateLimiter.md) | - |

## Interfaces

| Interface | Description |
| ------ | ------ |
| [BatchOptions](interfaces/BatchOptions.md) | - |
| [GetLeaderboardParams](interfaces/GetLeaderboardParams.md) | - |
| [GetProfileStatsParams](interfaces/GetProfileStatsParams.md) | - |
| [GetTotalsParams](interfaces/GetTotalsParams.md) | - |
| [LeaderboardEntry](interfaces/LeaderboardEntry.md) | - |
| [LeaderboardPage](interfaces/LeaderboardPage.md) | - |
| [NetworkCache](interfaces/NetworkCache.md) | caches network responses to avoid redundant requests. uses keyv's in-memory adapter by default. pass a persistent adapter for shared or durable caching. |
| [NetworkClientOptions](interfaces/NetworkClientOptions.md) | - |
| [PikaNetworkClientOptions](interfaces/PikaNetworkClientOptions.md) | - |
| [ProfileStat](interfaces/ProfileStat.md) | - |
| [RateLimiterOptions](interfaces/RateLimiterOptions.md) | proactive token-bucket rate limiter for APIs that provide no `RateLimit-*` headers |
| [RequestConfig](interfaces/RequestConfig.md) | - |

## Type Aliases

| Type Alias | Description |
| ------ | ------ |
| [BatchResult](type-aliases/BatchResult.md) | - |
| [PikaNetworkClanResponse](type-aliases/PikaNetworkClanResponse.md) | - |
| [PikaNetworkGamemode](type-aliases/PikaNetworkGamemode.md) | - |
| [PikaNetworkInterval](type-aliases/PikaNetworkInterval.md) | - |
| [PikaNetworkLeaderboardResponse](type-aliases/PikaNetworkLeaderboardResponse.md) | - |
| [PikaNetworkMode](type-aliases/PikaNetworkMode.md) | - |
| [PikaNetworkProfileResponse](type-aliases/PikaNetworkProfileResponse.md) | - |
| [PikaNetworkStat](type-aliases/PikaNetworkStat.md) | - |
| [PikaNetworkStatKey](type-aliases/PikaNetworkStatKey.md) | - |
| [PikaNetworkTotalsResponse](type-aliases/PikaNetworkTotalsResponse.md) | - |
| [ProfileStatAccessor](type-aliases/ProfileStatAccessor.md) | provides direct access to profile stats through the `StatKey` hierarchy. stats that were not fetched or have no recorded value resolve to `null`. |
| [ProfileStats](type-aliases/ProfileStats.md) | profile stats returned as a normal `ProfileStat[]` with an additional non-enumerable `StatKey` accessor for direct, autocomplete-friendly lookup. |

## Variables

| Variable | Description |
| ------ | ------ |
| [Gamemode](variables/Gamemode.md) | ergonomic alias |
| [Interval](variables/Interval.md) | - |
| [Mode](variables/Mode.md) | - |
| [PikaNetworkClanResponseSchema](variables/PikaNetworkClanResponseSchema.md) | GET /clans/{clanName} HACK: kept permissive |
| [PikaNetworkDefaultBaseUrl](variables/PikaNetworkDefaultBaseUrl.md) | shared PikaNetwork client defaults |
| [PikaNetworkDefaultRateLimit](variables/PikaNetworkDefaultRateLimit.md) | REVIEW: derived from live API load testing (approximated). override via `rateLimit` when using different request constraints. |
| [PikaNetworkGamemodes](variables/PikaNetworkGamemodes.md) | - |
| [PikaNetworkIntervals](variables/PikaNetworkIntervals.md) | - |
| [PikaNetworkLeaderboardResponseSchema](variables/PikaNetworkLeaderboardResponseSchema.md) | - |
| [PikaNetworkModes](variables/PikaNetworkModes.md) | valid `mode` values per gamemode |
| [PikaNetworkProfileResponseSchema](variables/PikaNetworkProfileResponseSchema.md) | GET /profile/{username} HACK: kept permissive since this endpoint isn't formally specced and fields may vary by account state |
| [PikaNetworkProfileStatsResponseSchema](variables/PikaNetworkProfileStatsResponseSchema.md) | GET /profile/{username}/leaderboard |
| [PikaNetworkRecapResponseSchema](variables/PikaNetworkRecapResponseSchema.md) | GET /recaps/{gameId} HACK: kept permissive |
| [PikaNetworkRequiredMode](variables/PikaNetworkRequiredMode.md) | - |
| [PikaNetworkStatAliases](variables/PikaNetworkStatAliases.md) | querying the alias returns the same data as the canonical stat |
| [PikaNetworkStats](variables/PikaNetworkStats.md) | - |
| [PikaNetworkTotalsResponseSchema](variables/PikaNetworkTotalsResponseSchema.md) | - |
| [Stat](variables/Stat.md) | - |
| [StatKey](variables/StatKey.md) | - |
| [YearlyCapableGamemodes](variables/YearlyCapableGamemodes.md) | interval=yearly doesn't work outside these gamemodes. enforced at the type and request level. |

## Functions

| Function | Description |
| ------ | ------ |
| [setLogLevel](functions/setLogLevel.md) | - |
| [toLeaderboardPage](functions/toLeaderboardPage.md) | - |
| [withStatKeyAccessor](functions/withStatKeyAccessor.md) | wraps a raw `ProfileStat[]` with the `.StatKey.<Gamemode>.<Stat>` accessor |
