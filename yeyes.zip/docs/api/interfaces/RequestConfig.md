# Interface: RequestConfig

## Properties

| Property | Type | Description |
| ------ | ------ | ------ |
| <a id="cachettlms"></a> `cacheTtlMs?` | `number` | override the cache TTL for this call |
| <a id="maxretries"></a> `maxRetries?` | `number` | max retry attempts on 429/5xx default: 2 |
| <a id="signal"></a> `signal?` | `AbortSignal` | abort signal to cancel the request |
| <a id="skipcache"></a> `skipCache?` | `boolean` | bypass the cache for this call even if caching is enabled |
| <a id="timeoutms"></a> `timeoutMs?` | `number` | abort the request if it takes longer than this default: 10000ms |
