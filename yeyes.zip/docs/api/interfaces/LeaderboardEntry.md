# Interface: LeaderboardEntry

## Properties

| Property | Type |
| ------ | ------ |
| <a id="clan"></a> `clan?` | `string` |
| <a id="id"></a> `id` | `string` |
| <a id="place"></a> `place` | `number` |
| <a id="rank"></a> `rank?` | `string` |
| <a id="value"></a> `value` | `number` |
