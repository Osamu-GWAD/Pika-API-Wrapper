# Interface: RateLimiterOptions

proactive token-bucket rate limiter for APIs that provide no `RateLimit-*` headers

networks set their own defaults;
see each client's constructor for the values and where they came from.

## Properties

| Property | Type | Description |
| ------ | ------ | ------ |
| <a id="burst"></a> `burst?` | `number` | maximum burst capacity |
| <a id="ratepersecond"></a> `ratePerSecond?` | `number` | sustained request rate, in reqs/sec |
