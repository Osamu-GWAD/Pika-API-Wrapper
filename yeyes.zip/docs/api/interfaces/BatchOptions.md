# Interface: BatchOptions

## Properties

| Property | Type |
| ------ | ------ |
| <a id="concurrency"></a> `concurrency?` | `number` |
| <a id="onprogress"></a> `onProgress?` | (`completed`: `number`, `total`: `number`) => `void` |
| <a id="throwonerror"></a> `throwOnError?` | `boolean` |
