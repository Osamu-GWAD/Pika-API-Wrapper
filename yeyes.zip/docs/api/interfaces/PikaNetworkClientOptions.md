# Interface: PikaNetworkClientOptions

## Extends

- [`NetworkClientOptions`](NetworkClientOptions.md)

## Properties

| Property | Type | Description | Inherited from |
| ------ | ------ | ------ | ------ |
| <a id="baseurl"></a> `baseUrl?` | `string` | - | - |
| <a id="batchconcurrency"></a> `batchConcurrency?` | `number` | default max simultaneous in-flight operations for `batch()` calls; individual calls are unaffected. | [`NetworkClientOptions`](NetworkClientOptions.md).[`batchConcurrency`](NetworkClientOptions.md#batchconcurrency) |
| <a id="cache"></a> `cache?` | `false` \| [`NetworkCache`](NetworkCache.md) | custom cache backend defaults to keyv's in-memory adapter. pass `false` to disable caching. | [`NetworkClientOptions`](NetworkClientOptions.md).[`cache`](NetworkClientOptions.md#cache) |
| <a id="defaultcachettlms"></a> `defaultCacheTtlMs?` | `number` | default ttl for cached reads | [`NetworkClientOptions`](NetworkClientOptions.md).[`defaultCacheTtlMs`](NetworkClientOptions.md#defaultcachettlms) |
| <a id="maxretries"></a> `maxRetries?` | `number` | - | [`NetworkClientOptions`](NetworkClientOptions.md).[`maxRetries`](NetworkClientOptions.md#maxretries) |
| <a id="ratelimit"></a> `rateLimit?` | [`RateLimiterOptions`](RateLimiterOptions.md) | overrides the default rate limiter configuration. see `rate-limiter.ts` for the rationale behind why defaults are conservative. | [`NetworkClientOptions`](NetworkClientOptions.md).[`rateLimit`](NetworkClientOptions.md#ratelimit) |
| <a id="timeoutms"></a> `timeoutMs?` | `number` | - | [`NetworkClientOptions`](NetworkClientOptions.md).[`timeoutMs`](NetworkClientOptions.md#timeoutms) |
| <a id="useragent"></a> `userAgent?` | `string` | - | [`NetworkClientOptions`](NetworkClientOptions.md).[`userAgent`](NetworkClientOptions.md#useragent) |
