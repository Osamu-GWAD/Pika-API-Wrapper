# Interface: NetworkClientOptions

## Extended by

- [`PikaNetworkClientOptions`](PikaNetworkClientOptions.md)

## Properties

| Property | Type | Description |
| ------ | ------ | ------ |
| <a id="batchconcurrency"></a> `batchConcurrency?` | `number` | default max simultaneous in-flight operations for `batch()` calls; individual calls are unaffected. |
| <a id="cache"></a> `cache?` | `false` \| [`NetworkCache`](NetworkCache.md) | custom cache backend defaults to keyv's in-memory adapter. pass `false` to disable caching. |
| <a id="defaultcachettlms"></a> `defaultCacheTtlMs?` | `number` | default ttl for cached reads |
| <a id="maxretries"></a> `maxRetries?` | `number` | - |
| <a id="ratelimit"></a> `rateLimit?` | [`RateLimiterOptions`](RateLimiterOptions.md) | overrides the default rate limiter configuration. see `rate-limiter.ts` for the rationale behind why defaults are conservative. |
| <a id="timeoutms"></a> `timeoutMs?` | `number` | - |
| <a id="useragent"></a> `userAgent?` | `string` | - |
