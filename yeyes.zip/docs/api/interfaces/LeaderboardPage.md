# Interface: LeaderboardPage

## Properties

| Property | Type |
| ------ | ------ |
| <a id="entries"></a> `entries` | [`LeaderboardEntry`](LeaderboardEntry.md)[] |
| <a id="totaltracked"></a> `totalTracked` | `number` |
