# Interface: GetTotalsParams\<G\>

## Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* [`PikaNetworkGamemode`](../type-aliases/PikaNetworkGamemode.md) |

## Properties

| Property | Type |
| ------ | ------ |
| <a id="gamemode"></a> `gamemode` | `G` |
