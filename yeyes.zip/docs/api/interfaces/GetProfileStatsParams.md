# Interface: GetProfileStatsParams\<G\>

## Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* [`PikaNetworkGamemode`](../type-aliases/PikaNetworkGamemode.md) |

## Properties

| Property | Type |
| ------ | ------ |
| <a id="gamemode"></a> `gamemode` | `G` |
| <a id="interval"></a> `interval?` | `"total"` \| `"weekly"` \| `"monthly"` \| `"yearly"` |
| <a id="mode"></a> `mode?` | [`PikaNetworkMode`](../type-aliases/PikaNetworkMode.md)\<`G`\> |
| <a id="username"></a> `username` | `string` |
