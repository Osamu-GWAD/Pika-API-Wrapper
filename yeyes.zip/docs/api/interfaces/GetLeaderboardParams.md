# Interface: GetLeaderboardParams\<G\>

## Type Parameters

| Type Parameter |
| ------ |
| `G` *extends* [`PikaNetworkGamemode`](../type-aliases/PikaNetworkGamemode.md) |

## Properties

| Property | Type | Description |
| ------ | ------ | ------ |
| <a id="gamemode"></a> `gamemode` | `G` | - |
| <a id="interval"></a> `interval?` | `"total"` \| `"weekly"` \| `"monthly"` \| `"yearly"` | - |
| <a id="limit"></a> `limit?` | `number` | - |
| <a id="mode"></a> `mode?` | [`PikaNetworkMode`](../type-aliases/PikaNetworkMode.md)\<`G`\> | - |
| <a id="page"></a> `page?` | `number` | 1-indexed page number |
| <a id="stat"></a> `stat` | keyof `object`\[`G`\] | - |
