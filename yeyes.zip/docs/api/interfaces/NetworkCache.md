# Interface: NetworkCache

caches network responses to avoid redundant requests.
uses keyv's in-memory adapter by default.
pass a persistent adapter for shared or durable caching.

## Methods

### clear()

```ts
clear(): Promise<void>;
```

#### Returns

`Promise`\<`void`\>

***

### delete()

```ts
delete(key: string): Promise<void>;
```

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `key` | `string` |

#### Returns

`Promise`\<`void`\>

***

### get()

```ts
get<T>(key: string): Promise<T | undefined>;
```

#### Type Parameters

| Type Parameter |
| ------ |
| `T` |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `key` | `string` |

#### Returns

`Promise`\<`T` \| `undefined`\>

***

### set()

```ts
set<T>(
   key: string, 
   value: T, 
ttlMs?: number): Promise<void>;
```

#### Type Parameters

| Type Parameter |
| ------ |
| `T` |

#### Parameters

| Parameter | Type |
| ------ | ------ |
| `key` | `string` |
| `value` | `T` |
| `ttlMs?` | `number` |

#### Returns

`Promise`\<`void`\>
