# Interface: ProfileStat

## Properties

| Property | Type |
| ------ | ------ |
| <a id="hasscore"></a> `hasScore` | `boolean` |
| <a id="place"></a> `place` | `number` \| `null` |
| <a id="statkey"></a> `statKey` | `string` |
| <a id="totaltracked"></a> `totalTracked` | `number` |
| <a id="value"></a> `value` | `number` \| `null` |
