# Variable: PikaNetworkTotalsResponseSchema

```ts
const PikaNetworkTotalsResponseSchema: ZodArray<ZodObject<{
  average: ZodNumber;
  name: ZodString;
  sum: ZodNumber;
  total: ZodNumber;
}, "strip", ZodTypeAny, {
  average: number;
  name: string;
  sum: number;
  total: number;
}, {
  average: number;
  name: string;
  sum: number;
  total: number;
}>, "many">;
```
