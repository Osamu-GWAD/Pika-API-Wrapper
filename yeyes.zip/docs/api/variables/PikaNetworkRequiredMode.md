# Variable: PikaNetworkRequiredMode

```ts
const PikaNetworkRequiredMode: object;
```

## Type Declaration

### pillars

```ts
readonly pillars: "Seasonal" = 'Seasonal';
```
