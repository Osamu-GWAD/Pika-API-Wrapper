# Variable: StatKey

```ts
const StatKey: object;
```

## Type Declaration

### BedWars

```ts
readonly BedWars: object;
```

#### Type Declaration

#### BedWars.BedDestroyed

```ts
readonly BedDestroyed: "Beds destroyed" = 'Beds destroyed';
```

#### BedWars.BowKills

```ts
readonly BowKills: "Bow kills" = 'Bow kills';
```

#### BedWars.FinalKills

```ts
readonly FinalKills: "Final kills" = 'Final kills';
```

#### BedWars.HighestWinStreak

```ts
readonly HighestWinStreak: "Highest winstreak reached" = 'Highest winstreak reached';
```

#### BedWars.Kills

```ts
readonly Kills: "Kills" = 'Kills';
```

#### BedWars.Played

```ts
readonly Played: "Games played" = 'Games played';
```

#### BedWars.Wins

```ts
readonly Wins: "Wins" = 'Wins';
```

### Dungeons

```ts
readonly Dungeons: object;
```

#### Type Declaration

#### Dungeons.BossDamageDealtTotal

```ts
readonly BossDamageDealtTotal: "Total Boss Damage" = 'Total Boss Damage';
```

#### Dungeons.BossKillsTotal

```ts
readonly BossKillsTotal: "Total Boss Kills" = 'Total Boss Kills';
```

#### Dungeons.MobDamageDealtTotal

```ts
readonly MobDamageDealtTotal: "Total Mob Damage" = 'Total Mob Damage';
```

#### Dungeons.MobKillsTotal

```ts
readonly MobKillsTotal: "Total Mob Kills" = 'Total Mob Kills';
```

#### Dungeons.PetsDeleted

```ts
readonly PetsDeleted: "Pets Deleted" = 'Pets Deleted';
```

#### Dungeons.PetsFused

```ts
readonly PetsFused: "Pets Fused" = 'Pets Fused';
```

#### Dungeons.PetsHatched

```ts
readonly PetsHatched: "Pets Hatched" = 'Pets Hatched';
```

#### Dungeons.PetsUsedInFusion

```ts
readonly PetsUsedInFusion: "Pets Used in Fusion" = 'Pets Used in Fusion';
```

#### Dungeons.PityRolls

```ts
readonly PityRolls: "Pity Rolls" = 'Pity Rolls';
```

#### Dungeons.Rebirth

```ts
readonly Rebirth: "Rebirth" = 'Rebirth';
```

#### Dungeons.TotalBombsThrown

```ts
readonly TotalBombsThrown: "Total Bombs Thrown" = 'Total Bombs Thrown';
```

#### Dungeons.TotalCrystalsObtained

```ts
readonly TotalCrystalsObtained: "Total Crystals Obtained" = 'Total Crystals Obtained';
```

#### Dungeons.TotalEnchantActivations

```ts
readonly TotalEnchantActivations: "Total Enchant Activations" = 'Total Enchant Activations';
```

#### Dungeons.TotalPerksRolled

```ts
readonly TotalPerksRolled: "Total Perks Rolled" = 'Total Perks Rolled';
```

### GenPvp

```ts
readonly GenPvp: object;
```

#### Type Declaration

#### GenPvp.Balance

```ts
readonly Balance: "Balance" = 'Balance';
```

#### GenPvp.CurrentKillstreak

```ts
readonly CurrentKillstreak: "Current Killstreak" = 'Current Killstreak';
```

#### GenPvp.Deaths

```ts
readonly Deaths: "Deaths" = 'Deaths';
```

#### GenPvp.HighestKillstreak

```ts
readonly HighestKillstreak: "Highest Killstreak" = 'Highest Killstreak';
```

#### GenPvp.Kills

```ts
readonly Kills: "Kills" = 'Kills';
```

#### GenPvp.Level

```ts
readonly Level: "Level" = 'Level';
```

### KitPvp

```ts
readonly KitPvp: object;
```

#### Type Declaration

#### KitPvp.Balance

```ts
readonly Balance: "Balance" = 'Balance';
```

#### KitPvp.CurrentKillstreak

```ts
readonly CurrentKillstreak: "Current Killstreak" = 'Current Killstreak';
```

#### KitPvp.Kills

```ts
readonly Kills: "Kills" = 'Kills';
```

#### KitPvp.KitpvpLevel

```ts
readonly KitpvpLevel: "Level" = 'Level';
```

#### KitPvp.Prestige

```ts
readonly Prestige: "Prestige" = 'Prestige';
```

#### KitPvp.TotalKothsWon

```ts
readonly TotalKothsWon: "Total koths won" = 'Total koths won';
```

### OneBlock

```ts
readonly OneBlock: object;
```

#### Type Declaration

#### OneBlock.Balance

```ts
readonly Balance: "Balance" = 'Balance';
```

#### OneBlock.CustomCropsFarmed

```ts
readonly CustomCropsFarmed: "Custom Crops Farmed" = 'Custom Crops Farmed';
```

#### OneBlock.MobsKilled

```ts
readonly MobsKilled: "Mobs Killed" = 'Mobs Killed';
```

#### OneBlock.OneBlockBroken

```ts
readonly OneBlockBroken: "One Block Broken" = 'One Block Broken';
```

#### OneBlock.PlayerLevel

```ts
readonly PlayerLevel: "Player Level" = 'Player Level';
```

### OpFactions

```ts
readonly OpFactions: object;
```

#### Type Declaration

#### OpFactions.Balance

```ts
readonly Balance: "Balance" = 'Balance';
```

#### OpFactions.Deaths

```ts
readonly Deaths: "Deaths" = 'Deaths';
```

#### OpFactions.HarvestSugarCane

```ts
readonly HarvestSugarCane: "Harvest Sugar Cane" = 'Harvest Sugar Cane';
```

#### OpFactions.HighestKillstreak

```ts
readonly HighestKillstreak: "Highest Killstreak" = 'Highest Killstreak';
```

#### OpFactions.Kills

```ts
readonly Kills: "Kills" = 'Kills';
```

#### OpFactions.MobsKilled

```ts
readonly MobsKilled: "Mobs Killed" = 'Mobs Killed';
```

#### OpFactions.PlayerLevel

```ts
readonly PlayerLevel: "Player Level" = 'Player Level';
```

#### OpFactions.TotalKothsWon

```ts
readonly TotalKothsWon: "Total koths won" = 'Total koths won';
```

### OpLifesteal

```ts
readonly OpLifesteal: object;
```

#### Type Declaration

#### OpLifesteal.Balance

```ts
readonly Balance: "Balance" = 'Balance';
```

#### OpLifesteal.BlocksBroken

```ts
readonly BlocksBroken: "Blocks Broken" = 'Blocks Broken';
```

#### OpLifesteal.BlocksPlaced

```ts
readonly BlocksPlaced: "Blocks Placed" = 'Blocks Placed';
```

#### OpLifesteal.Deaths

```ts
readonly Deaths: "Deaths" = 'Deaths';
```

#### OpLifesteal.HighestKillstreak

```ts
readonly HighestKillstreak: "Highest Killstreak" = 'Highest Killstreak';
```

#### OpLifesteal.Kills

```ts
readonly Kills: "Kills" = 'Kills';
```

#### OpLifesteal.MobsKilled

```ts
readonly MobsKilled: "Mobs Killed" = 'Mobs Killed';
```

#### OpLifesteal.PlayerLevel

```ts
readonly PlayerLevel: "Player Level" = 'Player Level';
```

### OpPrison

```ts
readonly OpPrison: object;
```

#### Type Declaration

#### OpPrison.PrisonAscension

```ts
readonly PrisonAscension: "Ascension" = 'Ascension';
```

#### OpPrison.PrisonBeaconBalance

```ts
readonly PrisonBeaconBalance: "Beacons" = 'Beacons';
```

#### OpPrison.PrisonBlocksBroken

```ts
readonly PrisonBlocksBroken: "Blocks Broken" = 'Blocks Broken';
```

#### OpPrison.PrisonPrestige

```ts
readonly PrisonPrestige: "Prestige" = 'Prestige';
```

#### OpPrison.PrisonRawBlocksBroken

```ts
readonly PrisonRawBlocksBroken: "Raw Blocks Broken" = 'Raw Blocks Broken';
```

#### OpPrison.PrisonTokenBalance

```ts
readonly PrisonTokenBalance: "Tokens" = 'Tokens';
```

### OpSkyBlock

```ts
readonly OpSkyBlock: object;
```

#### Type Declaration

#### OpSkyBlock.AdventurerSkillLevel

```ts
readonly AdventurerSkillLevel: "Adventurer Skill Level" = 'Adventurer Skill Level';
```

#### OpSkyBlock.AlchemistSkillLevel

```ts
readonly AlchemistSkillLevel: "Alchemist Skill Level" = 'Alchemist Skill Level';
```

#### OpSkyBlock.ArcherySkillLevel

```ts
readonly ArcherySkillLevel: "Archery Skill Level" = 'Archery Skill Level';
```

#### OpSkyBlock.AxesSkillLevel

```ts
readonly AxesSkillLevel: "Axes Skill Level" = 'Axes Skill Level';
```

#### OpSkyBlock.Balance

```ts
readonly Balance: "Balance" = 'Balance';
```

#### OpSkyBlock.BankerSkillLevel

```ts
readonly BankerSkillLevel: "Banker Skill Level" = 'Banker Skill Level';
```

#### OpSkyBlock.FarmerSkillLevel

```ts
readonly FarmerSkillLevel: "Farmer Skill Level" = 'Farmer Skill Level';
```

#### OpSkyBlock.LuckySkillLevel

```ts
readonly LuckySkillLevel: "Lucky Skill Level" = 'Lucky Skill Level';
```

#### OpSkyBlock.MinerSkillLevel

```ts
readonly MinerSkillLevel: "Miner Skill Level" = 'Miner Skill Level';
```

#### OpSkyBlock.PlayerLevel

```ts
readonly PlayerLevel: "Player Level" = 'Player Level';
```

#### OpSkyBlock.SkillLevel

```ts
readonly SkillLevel: "Skill Level" = 'Skill Level';
```

#### OpSkyBlock.Souls

```ts
readonly Souls: "Souls" = 'Souls';
```

#### OpSkyBlock.SpecialOresMined

```ts
readonly SpecialOresMined: "Special Ores Mined" = 'Special Ores Mined';
```

#### OpSkyBlock.WizardSkillLevel

```ts
readonly WizardSkillLevel: "Wizard Skill Level" = 'Wizard Skill Level';
```

### Pillars

```ts
readonly Pillars: object;
```

#### Type Declaration

#### Pillars.Kills

```ts
readonly Kills: "Kills" = 'Kills';
```

#### Pillars.Played

```ts
readonly Played: "Games played" = 'Games played';
```

#### Pillars.Wins

```ts
readonly Wins: "Wins" = 'Wins';
```

### SkyMines

```ts
readonly SkyMines: object;
```

#### Type Declaration

#### SkyMines.Balance

```ts
readonly Balance: "Balance" = 'Balance';
```

#### SkyMines.BlocksMined

```ts
readonly BlocksMined: "Blocks Mined" = 'Blocks Mined';
```

#### SkyMines.BossesKilled

```ts
readonly BossesKilled: "Bosses Killed" = 'Bosses Killed';
```

#### SkyMines.Deaths

```ts
readonly Deaths: "Deaths" = 'Deaths';
```

#### SkyMines.HighestKillstreak

```ts
readonly HighestKillstreak: "Highest Killstreak" = 'Highest Killstreak';
```

#### SkyMines.Kills

```ts
readonly Kills: "Kills" = 'Kills';
```

#### SkyMines.PlayerLevel

```ts
readonly PlayerLevel: "Player Level" = 'Player Level';
```

### SkyPvp

```ts
readonly SkyPvp: object;
```

#### Type Declaration

#### SkyPvp.Balance

```ts
readonly Balance: "Balance" = 'Balance';
```

#### SkyPvp.CurrentKillstreak

```ts
readonly CurrentKillstreak: "Current Killstreak" = 'Current Killstreak';
```

#### SkyPvp.Deaths

```ts
readonly Deaths: "Deaths" = 'Deaths';
```

#### SkyPvp.HighestKillstreak

```ts
readonly HighestKillstreak: "Highest Killstreak" = 'Highest Killstreak';
```

#### SkyPvp.Kills

```ts
readonly Kills: "Kills" = 'Kills';
```

#### SkyPvp.LuckyCratesOpened

```ts
readonly LuckyCratesOpened: "Lucky Crates Opened" = 'Lucky Crates Opened';
```

#### SkyPvp.RankRating

```ts
readonly RankRating: "Rank Rating" = 'Rank Rating';
```

### Survival

```ts
readonly Survival: object;
```

#### Type Declaration

#### Survival.Balance

```ts
readonly Balance: "Balance" = 'Balance';
```

#### Survival.ExpCollected

```ts
readonly ExpCollected: "EXP Collected" = 'EXP Collected';
```

#### Survival.MobsKilled

```ts
readonly MobsKilled: "Mobs Killed" = 'Mobs Killed';
```

#### Survival.PlayerLevel

```ts
readonly PlayerLevel: "Player Level" = 'Player Level';
```

### UnrankedPractice

```ts
readonly UnrankedPractice: object;
```

#### Type Declaration

#### UnrankedPractice.HighestWinStreak

```ts
readonly HighestWinStreak: "Highest winstreak reached" = 'Highest winstreak reached';
```

#### UnrankedPractice.Kills

```ts
readonly Kills: "Kills" = 'Kills';
```

#### UnrankedPractice.Losses

```ts
readonly Losses: "Losses" = 'Losses';
```

#### UnrankedPractice.MeleeDealt

```ts
readonly MeleeDealt: "Hits dealt" = 'Hits dealt';
```

#### UnrankedPractice.MeleeTaken

```ts
readonly MeleeTaken: "Hits taken" = 'Hits taken';
```

#### UnrankedPractice.Played

```ts
readonly Played: "Games played" = 'Games played';
```

#### UnrankedPractice.VoidKills

```ts
readonly VoidKills: "Void kills" = 'Void kills';
```

#### UnrankedPractice.Wins

```ts
readonly Wins: "Wins" = 'Wins';
```
