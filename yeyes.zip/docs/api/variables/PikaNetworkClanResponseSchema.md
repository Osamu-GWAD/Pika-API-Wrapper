# Variable: PikaNetworkClanResponseSchema

```ts
const PikaNetworkClanResponseSchema: ZodObject<{
  createdAt: ZodOptional<ZodNumber>;
  members: ZodOptional<ZodArray<ZodUnknown, "many">>;
  name: ZodOptional<ZodString>;
  tag: ZodOptional<ZodString>;
  trophies: ZodOptional<ZodNumber>;
}, "passthrough", ZodTypeAny, objectOutputType<{
  createdAt: ZodOptional<ZodNumber>;
  members: ZodOptional<ZodArray<ZodUnknown, "many">>;
  name: ZodOptional<ZodString>;
  tag: ZodOptional<ZodString>;
  trophies: ZodOptional<ZodNumber>;
}, ZodTypeAny, "passthrough">, objectInputType<{
  createdAt: ZodOptional<ZodNumber>;
  members: ZodOptional<ZodArray<ZodUnknown, "many">>;
  name: ZodOptional<ZodString>;
  tag: ZodOptional<ZodString>;
  trophies: ZodOptional<ZodNumber>;
}, ZodTypeAny, "passthrough">>;
```

GET /clans/{clanName}
HACK: kept permissive
