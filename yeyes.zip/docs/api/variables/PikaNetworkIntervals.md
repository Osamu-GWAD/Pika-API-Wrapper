# Variable: PikaNetworkIntervals

```ts
const PikaNetworkIntervals: readonly ["total", "weekly", "monthly", "yearly"];
```
