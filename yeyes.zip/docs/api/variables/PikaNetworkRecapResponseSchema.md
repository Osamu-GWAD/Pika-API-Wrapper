# Variable: PikaNetworkRecapResponseSchema

```ts
const PikaNetworkRecapResponseSchema: ZodRecord<ZodString, ZodUnknown>;
```

GET /recaps/{gameId}
HACK: kept permissive
