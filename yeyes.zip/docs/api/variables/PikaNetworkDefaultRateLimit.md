# Variable: PikaNetworkDefaultRateLimit

```ts
const PikaNetworkDefaultRateLimit: object;
```

REVIEW: derived from live API load testing (approximated).
override via `rateLimit` when using different request constraints.

## Type Declaration

### burst

```ts
readonly burst: 16 = 16;
```

### ratePerSecond

```ts
readonly ratePerSecond: 350 = 350;
```
