# Variable: PikaNetworkProfileResponseSchema

```ts
const PikaNetworkProfileResponseSchema: ZodObject<{
  boosting: ZodOptional<ZodBoolean>;
  clan: ZodOptional<ZodNullable<ZodObject<{
     name: ZodOptional<ZodString>;
     tag: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     name?: string;
     tag?: string;
   }, {
     name?: string;
     tag?: string;
  }>>>;
  discord_boosting: ZodOptional<ZodBoolean>;
  discord_verified: ZodOptional<ZodBoolean>;
  email_verified: ZodOptional<ZodBoolean>;
  friends: ZodOptional<ZodArray<ZodUnknown, "many">>;
  lastSeen: ZodOptional<ZodNumber>;
  rank: ZodOptional<ZodObject<{
     experience: ZodOptional<ZodNumber>;
     level: ZodOptional<ZodNumber>;
     percentage: ZodOptional<ZodNumber>;
     rankDisplay: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     experience?: number;
     level?: number;
     percentage?: number;
     rankDisplay?: string;
   }, {
     experience?: number;
     level?: number;
     percentage?: number;
     rankDisplay?: string;
  }>>;
  ranks: ZodOptional<ZodArray<ZodObject<{
     displayName: ZodOptional<ZodString>;
     expiry: ZodOptional<ZodNumber>;
     name: ZodOptional<ZodString>;
     season: ZodOptional<ZodNullable<ZodString>>;
     server: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     displayName?: string;
     expiry?: number;
     name?: string;
     season?: string | null;
     server?: string;
   }, {
     displayName?: string;
     expiry?: number;
     name?: string;
     season?: string | null;
     server?: string;
  }>, "many">>;
  username: ZodOptional<ZodString>;
}, "passthrough", ZodTypeAny, objectOutputType<{
  boosting: ZodOptional<ZodBoolean>;
  clan: ZodOptional<ZodNullable<ZodObject<{
     name: ZodOptional<ZodString>;
     tag: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     name?: string;
     tag?: string;
   }, {
     name?: string;
     tag?: string;
  }>>>;
  discord_boosting: ZodOptional<ZodBoolean>;
  discord_verified: ZodOptional<ZodBoolean>;
  email_verified: ZodOptional<ZodBoolean>;
  friends: ZodOptional<ZodArray<ZodUnknown, "many">>;
  lastSeen: ZodOptional<ZodNumber>;
  rank: ZodOptional<ZodObject<{
     experience: ZodOptional<ZodNumber>;
     level: ZodOptional<ZodNumber>;
     percentage: ZodOptional<ZodNumber>;
     rankDisplay: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     experience?: number;
     level?: number;
     percentage?: number;
     rankDisplay?: string;
   }, {
     experience?: number;
     level?: number;
     percentage?: number;
     rankDisplay?: string;
  }>>;
  ranks: ZodOptional<ZodArray<ZodObject<{
     displayName: ZodOptional<ZodString>;
     expiry: ZodOptional<ZodNumber>;
     name: ZodOptional<ZodString>;
     season: ZodOptional<ZodNullable<ZodString>>;
     server: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     displayName?: string;
     expiry?: number;
     name?: string;
     season?: string | null;
     server?: string;
   }, {
     displayName?: string;
     expiry?: number;
     name?: string;
     season?: string | null;
     server?: string;
  }>, "many">>;
  username: ZodOptional<ZodString>;
}, ZodTypeAny, "passthrough">, objectInputType<{
  boosting: ZodOptional<ZodBoolean>;
  clan: ZodOptional<ZodNullable<ZodObject<{
     name: ZodOptional<ZodString>;
     tag: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     name?: string;
     tag?: string;
   }, {
     name?: string;
     tag?: string;
  }>>>;
  discord_boosting: ZodOptional<ZodBoolean>;
  discord_verified: ZodOptional<ZodBoolean>;
  email_verified: ZodOptional<ZodBoolean>;
  friends: ZodOptional<ZodArray<ZodUnknown, "many">>;
  lastSeen: ZodOptional<ZodNumber>;
  rank: ZodOptional<ZodObject<{
     experience: ZodOptional<ZodNumber>;
     level: ZodOptional<ZodNumber>;
     percentage: ZodOptional<ZodNumber>;
     rankDisplay: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     experience?: number;
     level?: number;
     percentage?: number;
     rankDisplay?: string;
   }, {
     experience?: number;
     level?: number;
     percentage?: number;
     rankDisplay?: string;
  }>>;
  ranks: ZodOptional<ZodArray<ZodObject<{
     displayName: ZodOptional<ZodString>;
     expiry: ZodOptional<ZodNumber>;
     name: ZodOptional<ZodString>;
     season: ZodOptional<ZodNullable<ZodString>>;
     server: ZodOptional<ZodString>;
   }, "strip", ZodTypeAny, {
     displayName?: string;
     expiry?: number;
     name?: string;
     season?: string | null;
     server?: string;
   }, {
     displayName?: string;
     expiry?: number;
     name?: string;
     season?: string | null;
     server?: string;
  }>, "many">>;
  username: ZodOptional<ZodString>;
}, ZodTypeAny, "passthrough">>;
```

GET /profile/{username}
HACK: kept permissive since this endpoint isn't formally specced and fields may vary by account state
