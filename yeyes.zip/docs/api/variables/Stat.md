# Variable: Stat

```ts
const Stat: object;
```

## Type Declaration

### BedWars

```ts
readonly BedWars: object;
```

#### Type Declaration

#### BedWars.BedDestroyed

```ts
readonly BedDestroyed: "BED_DESTROYED" = 'BED_DESTROYED';
```

#### BedWars.BowKills

```ts
readonly BowKills: "BOW_KILLS" = 'BOW_KILLS';
```

#### BedWars.FinalKills

```ts
readonly FinalKills: "FINAL_KILLS" = 'FINAL_KILLS';
```

#### BedWars.HighestWinStreak

```ts
readonly HighestWinStreak: "HIGHEST_WIN_STREAK" = 'HIGHEST_WIN_STREAK';
```

#### BedWars.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### BedWars.Played

```ts
readonly Played: "played" = 'played';
```

#### BedWars.Wins

```ts
readonly Wins: "wins" = 'wins';
```

### Dungeons

```ts
readonly Dungeons: object;
```

#### Type Declaration

#### Dungeons.BossDamageDealtTotal

```ts
readonly BossDamageDealtTotal: "BOSS_DAMAGE_DEALT_TOTAL" = 'BOSS_DAMAGE_DEALT_TOTAL';
```

#### Dungeons.BossKillsTotal

```ts
readonly BossKillsTotal: "BOSS_KILLS_TOTAL" = 'BOSS_KILLS_TOTAL';
```

#### Dungeons.MobDamageDealtTotal

```ts
readonly MobDamageDealtTotal: "MOB_DAMAGE_DEALT_TOTAL" = 'MOB_DAMAGE_DEALT_TOTAL';
```

#### Dungeons.MobKillsTotal

```ts
readonly MobKillsTotal: "MOB_KILLS_TOTAL" = 'MOB_KILLS_TOTAL';
```

#### Dungeons.PetsDeleted

```ts
readonly PetsDeleted: "PETS_DELETED" = 'PETS_DELETED';
```

#### Dungeons.PetsFused

```ts
readonly PetsFused: "PETS_FUSED" = 'PETS_FUSED';
```

#### Dungeons.PetsHatched

```ts
readonly PetsHatched: "PETS_HATCHED" = 'PETS_HATCHED';
```

#### Dungeons.PetsUsedInFusion

```ts
readonly PetsUsedInFusion: "PETS_USED_IN_FUSION" = 'PETS_USED_IN_FUSION';
```

#### Dungeons.PityRolls

```ts
readonly PityRolls: "PITY_ROLLS" = 'PITY_ROLLS';
```

#### Dungeons.Rebirth

```ts
readonly Rebirth: "REBIRTH" = 'REBIRTH';
```

#### Dungeons.TotalBombsThrown

```ts
readonly TotalBombsThrown: "TOTAL_BOMBS_THROWN" = 'TOTAL_BOMBS_THROWN';
```

#### Dungeons.TotalCrystalsObtained

```ts
readonly TotalCrystalsObtained: "TOTAL_CRYSTALS_OBTAINED" = 'TOTAL_CRYSTALS_OBTAINED';
```

#### Dungeons.TotalEnchantActivations

```ts
readonly TotalEnchantActivations: "TOTAL_ENCHANT_ACTIVATIONS" = 'TOTAL_ENCHANT_ACTIVATIONS';
```

#### Dungeons.TotalPerksRolled

```ts
readonly TotalPerksRolled: "TOTAL_PERKS_ROLLED" = 'TOTAL_PERKS_ROLLED';
```

### GenPvp

```ts
readonly GenPvp: object;
```

#### Type Declaration

#### GenPvp.Balance

```ts
readonly Balance: "balance" = 'balance';
```

#### GenPvp.CurrentKillstreak

```ts
readonly CurrentKillstreak: "CURRENT_KILLSTREAK" = 'CURRENT_KILLSTREAK';
```

#### GenPvp.Deaths

```ts
readonly Deaths: "DEATHS" = 'DEATHS';
```

#### GenPvp.HighestKillstreak

```ts
readonly HighestKillstreak: "HIGHEST_KILLSTREAK" = 'HIGHEST_KILLSTREAK';
```

#### GenPvp.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### GenPvp.Level

```ts
readonly Level: "LEVEL" = 'LEVEL';
```

### KitPvp

```ts
readonly KitPvp: object;
```

#### Type Declaration

#### KitPvp.Balance

```ts
readonly Balance: "balance" = 'balance';
```

#### KitPvp.CurrentKillstreak

```ts
readonly CurrentKillstreak: "CURRENT_KILLSTREAK" = 'CURRENT_KILLSTREAK';
```

#### KitPvp.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### KitPvp.KitpvpLevel

```ts
readonly KitpvpLevel: "KITPVP_LEVEL" = 'KITPVP_LEVEL';
```

#### KitPvp.Prestige

```ts
readonly Prestige: "PRESTIGE" = 'PRESTIGE';
```

#### KitPvp.TotalKothsWon

```ts
readonly TotalKothsWon: "TOTAL_KOTHS_WON" = 'TOTAL_KOTHS_WON';
```

### OneBlock

```ts
readonly OneBlock: object;
```

#### Type Declaration

#### OneBlock.Balance

```ts
readonly Balance: "balance" = 'balance';
```

#### OneBlock.CustomCropsFarmed

```ts
readonly CustomCropsFarmed: "CUSTOM_CROPS_FARMED" = 'CUSTOM_CROPS_FARMED';
```

#### OneBlock.MobsKilled

```ts
readonly MobsKilled: "MOBS_KILLED" = 'MOBS_KILLED';
```

#### OneBlock.OneBlockBroken

```ts
readonly OneBlockBroken: "ONE_BLOCK_BROKEN" = 'ONE_BLOCK_BROKEN';
```

#### OneBlock.PlayerLevel

```ts
readonly PlayerLevel: "PLAYER_LEVEL" = 'PLAYER_LEVEL';
```

### OpFactions

```ts
readonly OpFactions: object;
```

#### Type Declaration

#### OpFactions.Balance

```ts
readonly Balance: "balance" = 'balance';
```

#### OpFactions.Deaths

```ts
readonly Deaths: "DEATHS" = 'DEATHS';
```

#### OpFactions.HarvestSugarCane

```ts
readonly HarvestSugarCane: "HARVEST_SUGAR_CANE" = 'HARVEST_SUGAR_CANE';
```

#### OpFactions.HighestKillstreak

```ts
readonly HighestKillstreak: "HIGHEST_KILLSTREAK" = 'HIGHEST_KILLSTREAK';
```

#### OpFactions.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### OpFactions.MobsKilled

```ts
readonly MobsKilled: "MOBS_KILLED" = 'MOBS_KILLED';
```

#### OpFactions.PlayerLevel

```ts
readonly PlayerLevel: "PLAYER_LEVEL" = 'PLAYER_LEVEL';
```

#### OpFactions.TotalKothsWon

```ts
readonly TotalKothsWon: "TOTAL_KOTHS_WON" = 'TOTAL_KOTHS_WON';
```

### OpLifesteal

```ts
readonly OpLifesteal: object;
```

#### Type Declaration

#### OpLifesteal.Balance

```ts
readonly Balance: "balance" = 'balance';
```

#### OpLifesteal.BlocksBroken

```ts
readonly BlocksBroken: "BLOCKS_BROKEN" = 'BLOCKS_BROKEN';
```

#### OpLifesteal.BlocksPlaced

```ts
readonly BlocksPlaced: "BLOCKS_PLACED" = 'BLOCKS_PLACED';
```

#### OpLifesteal.Deaths

```ts
readonly Deaths: "DEATHS" = 'DEATHS';
```

#### OpLifesteal.HighestKillstreak

```ts
readonly HighestKillstreak: "HIGHEST_KILLSTREAK" = 'HIGHEST_KILLSTREAK';
```

#### OpLifesteal.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### OpLifesteal.MobsKilled

```ts
readonly MobsKilled: "MOBS_KILLED" = 'MOBS_KILLED';
```

#### OpLifesteal.PlayerLevel

```ts
readonly PlayerLevel: "PLAYER_LEVEL" = 'PLAYER_LEVEL';
```

### OpPrison

```ts
readonly OpPrison: object;
```

#### Type Declaration

#### OpPrison.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### OpPrison.PrisonAscension

```ts
readonly PrisonAscension: "PRISON_ASCENSION" = 'PRISON_ASCENSION';
```

#### OpPrison.PrisonBeaconBalance

```ts
readonly PrisonBeaconBalance: "PRISON_BEACON_BALANCE" = 'PRISON_BEACON_BALANCE';
```

#### OpPrison.PrisonBlocksBroken

```ts
readonly PrisonBlocksBroken: "PRISON_BLOCKS_BROKEN" = 'PRISON_BLOCKS_BROKEN';
```

#### OpPrison.PrisonPrestige

```ts
readonly PrisonPrestige: "PRISON_PRESTIGE" = 'PRISON_PRESTIGE';
```

#### OpPrison.PrisonRawBlocksBroken

```ts
readonly PrisonRawBlocksBroken: "PRISON_RAW_BLOCKS_BROKEN" = 'PRISON_RAW_BLOCKS_BROKEN';
```

#### OpPrison.PrisonTokenBalance

```ts
readonly PrisonTokenBalance: "PRISON_TOKEN_BALANCE" = 'PRISON_TOKEN_BALANCE';
```

### OpSkyBlock

```ts
readonly OpSkyBlock: object;
```

#### Type Declaration

#### OpSkyBlock.AdventurerSkillLevel

```ts
readonly AdventurerSkillLevel: "ADVENTURER_SKILL_LEVEL" = 'ADVENTURER_SKILL_LEVEL';
```

#### OpSkyBlock.AlchemistSkillLevel

```ts
readonly AlchemistSkillLevel: "ALCHEMIST_SKILL_LEVEL" = 'ALCHEMIST_SKILL_LEVEL';
```

#### OpSkyBlock.ArcherySkillLevel

```ts
readonly ArcherySkillLevel: "ARCHERY_SKILL_LEVEL" = 'ARCHERY_SKILL_LEVEL';
```

#### OpSkyBlock.AxesSkillLevel

```ts
readonly AxesSkillLevel: "AXES_SKILL_LEVEL" = 'AXES_SKILL_LEVEL';
```

#### OpSkyBlock.Balance

```ts
readonly Balance: "balance" = 'balance';
```

#### OpSkyBlock.BankerSkillLevel

```ts
readonly BankerSkillLevel: "BANKER_SKILL_LEVEL" = 'BANKER_SKILL_LEVEL';
```

#### OpSkyBlock.FarmerSkillLevel

```ts
readonly FarmerSkillLevel: "FARMER_SKILL_LEVEL" = 'FARMER_SKILL_LEVEL';
```

#### OpSkyBlock.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### OpSkyBlock.LuckySkillLevel

```ts
readonly LuckySkillLevel: "LUCKY_SKILL_LEVEL" = 'LUCKY_SKILL_LEVEL';
```

#### OpSkyBlock.MinerSkillLevel

```ts
readonly MinerSkillLevel: "MINER_SKILL_LEVEL" = 'MINER_SKILL_LEVEL';
```

#### OpSkyBlock.PlayerLevel

```ts
readonly PlayerLevel: "PLAYER_LEVEL" = 'PLAYER_LEVEL';
```

#### OpSkyBlock.SkillLevel

```ts
readonly SkillLevel: "SKILL_LEVEL" = 'SKILL_LEVEL';
```

#### OpSkyBlock.Souls

```ts
readonly Souls: "Souls" = 'Souls';
```

#### OpSkyBlock.SpecialOresMined

```ts
readonly SpecialOresMined: "SPECIAL_ORES_MINED" = 'SPECIAL_ORES_MINED';
```

#### OpSkyBlock.WizardSkillLevel

```ts
readonly WizardSkillLevel: "WIZARD_SKILL_LEVEL" = 'WIZARD_SKILL_LEVEL';
```

### Pillars

```ts
readonly Pillars: object;
```

#### Type Declaration

#### Pillars.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### Pillars.Played

```ts
readonly Played: "played" = 'played';
```

#### Pillars.Wins

```ts
readonly Wins: "wins" = 'wins';
```

### SkyMines

```ts
readonly SkyMines: object;
```

#### Type Declaration

#### SkyMines.Balance

```ts
readonly Balance: "balance" = 'balance';
```

#### SkyMines.BlocksMined

```ts
readonly BlocksMined: "BLOCKS_MINED" = 'BLOCKS_MINED';
```

#### SkyMines.BossesKilled

```ts
readonly BossesKilled: "BOSSES_KILLED" = 'BOSSES_KILLED';
```

#### SkyMines.Deaths

```ts
readonly Deaths: "DEATHS" = 'DEATHS';
```

#### SkyMines.HighestKillstreak

```ts
readonly HighestKillstreak: "HIGHEST_KILLSTREAK" = 'HIGHEST_KILLSTREAK';
```

#### SkyMines.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### SkyMines.PlayerLevel

```ts
readonly PlayerLevel: "PLAYER_LEVEL" = 'PLAYER_LEVEL';
```

### SkyPvp

```ts
readonly SkyPvp: object;
```

#### Type Declaration

#### SkyPvp.Balance

```ts
readonly Balance: "balance" = 'balance';
```

#### SkyPvp.CurrentKillstreak

```ts
readonly CurrentKillstreak: "CURRENT_KILLSTREAK" = 'CURRENT_KILLSTREAK';
```

#### SkyPvp.Deaths

```ts
readonly Deaths: "DEATHS" = 'DEATHS';
```

#### SkyPvp.HighestKillstreak

```ts
readonly HighestKillstreak: "HIGHEST_KILLSTREAK" = 'HIGHEST_KILLSTREAK';
```

#### SkyPvp.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### SkyPvp.LuckyCratesOpened

```ts
readonly LuckyCratesOpened: "LUCKY_CRATES_OPENED" = 'LUCKY_CRATES_OPENED';
```

#### SkyPvp.RankRating

```ts
readonly RankRating: "RANK_RATING" = 'RANK_RATING';
```

### Survival

```ts
readonly Survival: object;
```

#### Type Declaration

#### Survival.Balance

```ts
readonly Balance: "balance" = 'balance';
```

#### Survival.ExpCollected

```ts
readonly ExpCollected: "EXP_COLLECTED" = 'EXP_COLLECTED';
```

#### Survival.MobsKilled

```ts
readonly MobsKilled: "MOBS_KILLED" = 'MOBS_KILLED';
```

#### Survival.PlayerLevel

```ts
readonly PlayerLevel: "PLAYER_LEVEL" = 'PLAYER_LEVEL';
```

### UnrankedPractice

```ts
readonly UnrankedPractice: object;
```

#### Type Declaration

#### UnrankedPractice.HighestWinStreak

```ts
readonly HighestWinStreak: "HIGHEST_WIN_STREAK" = 'HIGHEST_WIN_STREAK';
```

#### UnrankedPractice.Kills

```ts
readonly Kills: "kills" = 'kills';
```

#### UnrankedPractice.Losses

```ts
readonly Losses: "LOSSES" = 'LOSSES';
```

#### UnrankedPractice.MeleeDealt

```ts
readonly MeleeDealt: "MELEE_DEALT" = 'MELEE_DEALT';
```

#### UnrankedPractice.MeleeTaken

```ts
readonly MeleeTaken: "MELEE_TAKEN" = 'MELEE_TAKEN';
```

#### UnrankedPractice.Played

```ts
readonly Played: "played" = 'played';
```

#### UnrankedPractice.VoidKills

```ts
readonly VoidKills: "VOID_KILLS" = 'VOID_KILLS';
```

#### UnrankedPractice.Wins

```ts
readonly Wins: "wins" = 'wins';
```
