# Variable: PikaNetworkModes

```ts
const PikaNetworkModes: object;
```

valid `mode` values per gamemode

## Type Declaration

### bedwars

```ts
readonly bedwars: readonly ["ALL_MODES", "DOUBLES", "QUAD", "SOLO", "TRIPLES"];
```

### dungeons

```ts
readonly dungeons: readonly ["ALL_MODES"];
```

### genpvp

```ts
readonly genpvp: readonly ["ALL_MODES"];
```

### kitpvp

```ts
readonly kitpvp: readonly ["ALL_MODES"];
```

### oneblock

```ts
readonly oneblock: readonly ["ALL_MODES"];
```

### opfactions

```ts
readonly opfactions: readonly ["ALL_MODES"];
```

### oplifesteal

```ts
readonly oplifesteal: readonly ["ALL_MODES"];
```

### opprison

```ts
readonly opprison: readonly ["ALL_MODES"];
```

### opskyblock

```ts
readonly opskyblock: readonly ["ALL_MODES"];
```

### pillars

```ts
readonly pillars: readonly ["Seasonal"];
```

### skymines

```ts
readonly skymines: readonly ["ALL_MODES"];
```

### skypvp

```ts
readonly skypvp: readonly ["ALL_MODES"];
```

### survival

```ts
readonly survival: readonly ["ALL_MODES"];
```

### unrankedpractice

```ts
readonly unrankedpractice: readonly ["ALL_MODES", "ARCHER", "AXE_PVP", "AXE_SHIELD", "BATTLE_RUSH", "BED_FIGHT", "BOXING", "BUILD_UHC", "COMBO", "CRYSTAL", "DEBUFF", "DIAMOND_SMP", "FIREBALL_FIGHT", "GAPPLE", "MACE", "MINECART", "NETHERITE_NODEBUFF", "NODEBUFF", "PARKOUR", "PEARL_FIGHT", "SOUP", "SPLEEF", "SUMO", "SWORD", "THE_BRIDGE", "VOID_FIGHT"];
```
