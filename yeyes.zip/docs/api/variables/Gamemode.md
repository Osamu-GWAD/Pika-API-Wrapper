# Variable: Gamemode

```ts
const Gamemode: object;
```

ergonomic alias

## Type Declaration

### BedWars

```ts
readonly BedWars: "bedwars" = 'bedwars';
```

### Dungeons

```ts
readonly Dungeons: "dungeons" = 'dungeons';
```

### GenPvp

```ts
readonly GenPvp: "genpvp" = 'genpvp';
```

### KitPvp

```ts
readonly KitPvp: "kitpvp" = 'kitpvp';
```

### OneBlock

```ts
readonly OneBlock: "oneblock" = 'oneblock';
```

### OpFactions

```ts
readonly OpFactions: "opfactions" = 'opfactions';
```

### OpLifesteal

```ts
readonly OpLifesteal: "oplifesteal" = 'oplifesteal';
```

### OpPrison

```ts
readonly OpPrison: "opprison" = 'opprison';
```

### OpSkyBlock

```ts
readonly OpSkyBlock: "opskyblock" = 'opskyblock';
```

### Pillars

```ts
readonly Pillars: "pillars" = 'pillars';
```

### SkyMines

```ts
readonly SkyMines: "skymines" = 'skymines';
```

### SkyPvp

```ts
readonly SkyPvp: "skypvp" = 'skypvp';
```

### Survival

```ts
readonly Survival: "survival" = 'survival';
```

### UnrankedPractice

```ts
readonly UnrankedPractice: "unrankedpractice" = 'unrankedpractice';
```
