# Variable: PikaNetworkProfileStatsResponseSchema

```ts
const PikaNetworkProfileStatsResponseSchema: ZodRecord<ZodString, ZodObject<{
  entries: ZodNullable<ZodArray<ZodObject<{
     clan: ZodOptional<ZodString>;
     id: ZodString;
     place: ZodNumber;
     rank: ZodOptional<ZodString>;
     value: ZodEffects<ZodUnion<[ZodString, ZodNumber]>, number, string | number>;
   }, "strip", ZodTypeAny, {
     clan?: string;
     id: string;
     place: number;
     rank?: string;
     value: number;
   }, {
     clan?: string;
     id: string;
     place: number;
     rank?: string;
     value: string | number;
  }>, "many">>;
  metadata: ZodObject<{
     total: ZodNumber;
   }, "strip", ZodTypeAny, {
     total: number;
   }, {
     total: number;
  }>;
}, "strip", ZodTypeAny, {
  entries: object[] | null;
  metadata: {
     total: number;
  };
}, {
  entries: object[] | null;
  metadata: {
     total: number;
  };
}>>;
```

GET /profile/{username}/leaderboard
