# Variable: PikaNetworkDefaultBaseUrl

```ts
const PikaNetworkDefaultBaseUrl: "https://stats.pika-network.net/api" = 'https://stats.pika-network.net/api';
```

shared PikaNetwork client defaults

kept independent of the client implementation
so they can be consumed by docs, tests, etc
without importing the client itself.

this file has zero imports on purpose.
