# Variable: PikaNetworkGamemodes

```ts
const PikaNetworkGamemodes: readonly ["bedwars", "dungeons", "genpvp", "kitpvp", "oneblock", "opfactions", "oplifesteal", "opprison", "opskyblock", "pillars", "skymines", "skypvp", "survival", "unrankedpractice"];
```
