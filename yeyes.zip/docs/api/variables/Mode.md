# Variable: Mode

```ts
const Mode: object;
```

## Type Declaration

### BedWars

```ts
readonly BedWars: object;
```

#### Type Declaration

#### BedWars.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

#### BedWars.Doubles

```ts
readonly Doubles: "DOUBLES" = 'DOUBLES';
```

#### BedWars.Quad

```ts
readonly Quad: "QUAD" = 'QUAD';
```

#### BedWars.Solo

```ts
readonly Solo: "SOLO" = 'SOLO';
```

#### BedWars.Triples

```ts
readonly Triples: "TRIPLES" = 'TRIPLES';
```

### Dungeons

```ts
readonly Dungeons: object;
```

#### Type Declaration

#### Dungeons.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### GenPvp

```ts
readonly GenPvp: object;
```

#### Type Declaration

#### GenPvp.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### KitPvp

```ts
readonly KitPvp: object;
```

#### Type Declaration

#### KitPvp.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### OneBlock

```ts
readonly OneBlock: object;
```

#### Type Declaration

#### OneBlock.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### OpFactions

```ts
readonly OpFactions: object;
```

#### Type Declaration

#### OpFactions.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### OpLifesteal

```ts
readonly OpLifesteal: object;
```

#### Type Declaration

#### OpLifesteal.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### OpPrison

```ts
readonly OpPrison: object;
```

#### Type Declaration

#### OpPrison.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### OpSkyBlock

```ts
readonly OpSkyBlock: object;
```

#### Type Declaration

#### OpSkyBlock.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### Pillars

```ts
readonly Pillars: object;
```

#### Type Declaration

#### Pillars.Seasonal

```ts
readonly Seasonal: "Seasonal" = 'Seasonal';
```

### SkyMines

```ts
readonly SkyMines: object;
```

#### Type Declaration

#### SkyMines.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### SkyPvp

```ts
readonly SkyPvp: object;
```

#### Type Declaration

#### SkyPvp.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### Survival

```ts
readonly Survival: object;
```

#### Type Declaration

#### Survival.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

### UnrankedPractice

```ts
readonly UnrankedPractice: object;
```

#### Type Declaration

#### UnrankedPractice.AllModes

```ts
readonly AllModes: "ALL_MODES" = 'ALL_MODES';
```

#### UnrankedPractice.Archer

```ts
readonly Archer: "ARCHER" = 'ARCHER';
```

#### UnrankedPractice.AxePvp

```ts
readonly AxePvp: "AXE_PVP" = 'AXE_PVP';
```

#### UnrankedPractice.AxeShield

```ts
readonly AxeShield: "AXE_SHIELD" = 'AXE_SHIELD';
```

#### UnrankedPractice.BattleRush

```ts
readonly BattleRush: "BATTLE_RUSH" = 'BATTLE_RUSH';
```

#### UnrankedPractice.BedFight

```ts
readonly BedFight: "BED_FIGHT" = 'BED_FIGHT';
```

#### UnrankedPractice.Boxing

```ts
readonly Boxing: "BOXING" = 'BOXING';
```

#### UnrankedPractice.BuildUhc

```ts
readonly BuildUhc: "BUILD_UHC" = 'BUILD_UHC';
```

#### UnrankedPractice.Combo

```ts
readonly Combo: "COMBO" = 'COMBO';
```

#### UnrankedPractice.Crystal

```ts
readonly Crystal: "CRYSTAL" = 'CRYSTAL';
```

#### UnrankedPractice.Debuff

```ts
readonly Debuff: "DEBUFF" = 'DEBUFF';
```

#### UnrankedPractice.DiamondSmp

```ts
readonly DiamondSmp: "DIAMOND_SMP" = 'DIAMOND_SMP';
```

#### UnrankedPractice.FireballFight

```ts
readonly FireballFight: "FIREBALL_FIGHT" = 'FIREBALL_FIGHT';
```

#### UnrankedPractice.Gapple

```ts
readonly Gapple: "GAPPLE" = 'GAPPLE';
```

#### UnrankedPractice.Mace

```ts
readonly Mace: "MACE" = 'MACE';
```

#### UnrankedPractice.Minecart

```ts
readonly Minecart: "MINECART" = 'MINECART';
```

#### UnrankedPractice.NetheriteNodebuff

```ts
readonly NetheriteNodebuff: "NETHERITE_NODEBUFF" = 'NETHERITE_NODEBUFF';
```

#### UnrankedPractice.Nodebuff

```ts
readonly Nodebuff: "NODEBUFF" = 'NODEBUFF';
```

#### UnrankedPractice.Parkour

```ts
readonly Parkour: "PARKOUR" = 'PARKOUR';
```

#### UnrankedPractice.PearlFight

```ts
readonly PearlFight: "PEARL_FIGHT" = 'PEARL_FIGHT';
```

#### UnrankedPractice.Soup

```ts
readonly Soup: "SOUP" = 'SOUP';
```

#### UnrankedPractice.Spleef

```ts
readonly Spleef: "SPLEEF" = 'SPLEEF';
```

#### UnrankedPractice.Sumo

```ts
readonly Sumo: "SUMO" = 'SUMO';
```

#### UnrankedPractice.Sword

```ts
readonly Sword: "SWORD" = 'SWORD';
```

#### UnrankedPractice.TheBridge

```ts
readonly TheBridge: "THE_BRIDGE" = 'THE_BRIDGE';
```

#### UnrankedPractice.VoidFight

```ts
readonly VoidFight: "VOID_FIGHT" = 'VOID_FIGHT';
```
