# Variable: YearlyCapableGamemodes

```ts
const YearlyCapableGamemodes: readonly ["bedwars", "unrankedpractice"];
```

interval=yearly doesn't work outside these gamemodes.
enforced at the type and request level.
