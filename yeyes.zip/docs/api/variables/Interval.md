# Variable: Interval

```ts
const Interval: object;
```

## Type Declaration

### Monthly

```ts
readonly Monthly: "monthly" = 'monthly';
```

### Total

```ts
readonly Total: "total" = 'total';
```

### Weekly

```ts
readonly Weekly: "weekly" = 'weekly';
```

### Yearly

```ts
readonly Yearly: "yearly" = 'yearly';
```
