# Variable: PikaNetworkStatAliases

```ts
const PikaNetworkStatAliases: object;
```

querying the alias returns the same data as the canonical stat

## Type Declaration

### bedwars

```ts
readonly bedwars: object;
```

#### Type Declaration

#### bedwars.PROJECTILE\_KILLS

```ts
readonly PROJECTILE_KILLS: "BOW_KILLS" = 'BOW_KILLS';
```
