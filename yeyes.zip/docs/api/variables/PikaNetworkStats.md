# Variable: PikaNetworkStats

```ts
const PikaNetworkStats: object;
```

## Type Declaration

### bedwars

```ts
readonly bedwars: object;
```

#### Type Declaration

#### bedwars.BED\_DESTROYED

```ts
readonly BED_DESTROYED: "Beds destroyed" = 'Beds destroyed';
```

#### bedwars.BOW\_KILLS

```ts
readonly BOW_KILLS: "Bow kills" = 'Bow kills';
```

#### bedwars.FINAL\_KILLS

```ts
readonly FINAL_KILLS: "Final kills" = 'Final kills';
```

#### bedwars.HIGHEST\_WIN\_STREAK

```ts
readonly HIGHEST_WIN_STREAK: "Highest winstreak reached" = 'Highest winstreak reached';
```

#### bedwars.kills

```ts
readonly kills: "Kills" = 'Kills';
```

#### bedwars.played

```ts
readonly played: "Games played" = 'Games played';
```

#### bedwars.wins

```ts
readonly wins: "Wins" = 'Wins';
```

### dungeons

```ts
readonly dungeons: object;
```

#### Type Declaration

#### dungeons.BOSS\_DAMAGE\_DEALT\_TOTAL

```ts
readonly BOSS_DAMAGE_DEALT_TOTAL: "Total Boss Damage" = 'Total Boss Damage';
```

#### dungeons.BOSS\_KILLS\_TOTAL

```ts
readonly BOSS_KILLS_TOTAL: "Total Boss Kills" = 'Total Boss Kills';
```

#### dungeons.MOB\_DAMAGE\_DEALT\_TOTAL

```ts
readonly MOB_DAMAGE_DEALT_TOTAL: "Total Mob Damage" = 'Total Mob Damage';
```

#### dungeons.MOB\_KILLS\_TOTAL

```ts
readonly MOB_KILLS_TOTAL: "Total Mob Kills" = 'Total Mob Kills';
```

#### dungeons.PETS\_DELETED

```ts
readonly PETS_DELETED: "Pets Deleted" = 'Pets Deleted';
```

#### dungeons.PETS\_FUSED

```ts
readonly PETS_FUSED: "Pets Fused" = 'Pets Fused';
```

#### dungeons.PETS\_HATCHED

```ts
readonly PETS_HATCHED: "Pets Hatched" = 'Pets Hatched';
```

#### dungeons.PETS\_USED\_IN\_FUSION

```ts
readonly PETS_USED_IN_FUSION: "Pets Used in Fusion" = 'Pets Used in Fusion';
```

#### dungeons.PITY\_ROLLS

```ts
readonly PITY_ROLLS: "Pity Rolls" = 'Pity Rolls';
```

#### dungeons.REBIRTH

```ts
readonly REBIRTH: "Rebirth" = 'Rebirth';
```

#### dungeons.TOTAL\_BOMBS\_THROWN

```ts
readonly TOTAL_BOMBS_THROWN: "Total Bombs Thrown" = 'Total Bombs Thrown';
```

#### dungeons.TOTAL\_CRYSTALS\_OBTAINED

```ts
readonly TOTAL_CRYSTALS_OBTAINED: "Total Crystals Obtained" = 'Total Crystals Obtained';
```

#### dungeons.TOTAL\_ENCHANT\_ACTIVATIONS

```ts
readonly TOTAL_ENCHANT_ACTIVATIONS: "Total Enchant Activations" = 'Total Enchant Activations';
```

#### dungeons.TOTAL\_PERKS\_ROLLED

```ts
readonly TOTAL_PERKS_ROLLED: "Total Perks Rolled" = 'Total Perks Rolled';
```

### genpvp

```ts
readonly genpvp: object;
```

#### Type Declaration

#### genpvp.balance

```ts
readonly balance: "Balance" = 'Balance';
```

#### genpvp.CURRENT\_KILLSTREAK

```ts
readonly CURRENT_KILLSTREAK: "Current Killstreak" = 'Current Killstreak';
```

#### genpvp.DEATHS

```ts
readonly DEATHS: "Deaths" = 'Deaths';
```

#### genpvp.HIGHEST\_KILLSTREAK

```ts
readonly HIGHEST_KILLSTREAK: "Highest Killstreak" = 'Highest Killstreak';
```

#### genpvp.kills

```ts
readonly kills: "Kills" = 'Kills';
```

#### genpvp.LEVEL

```ts
readonly LEVEL: "Level" = 'Level';
```

### kitpvp

```ts
readonly kitpvp: object;
```

#### Type Declaration

#### kitpvp.balance

```ts
readonly balance: "Balance" = 'Balance';
```

#### kitpvp.CURRENT\_KILLSTREAK

```ts
readonly CURRENT_KILLSTREAK: "Current Killstreak" = 'Current Killstreak';
```

#### kitpvp.kills

```ts
readonly kills: "Kills" = 'Kills';
```

#### kitpvp.KITPVP\_LEVEL

```ts
readonly KITPVP_LEVEL: "Level" = 'Level';
```

#### kitpvp.PRESTIGE

```ts
readonly PRESTIGE: "Prestige" = 'Prestige';
```

#### kitpvp.TOTAL\_KOTHS\_WON

```ts
readonly TOTAL_KOTHS_WON: "Total koths won" = 'Total koths won';
```

### oneblock

```ts
readonly oneblock: object;
```

#### Type Declaration

#### oneblock.balance

```ts
readonly balance: "Balance" = 'Balance';
```

#### oneblock.CUSTOM\_CROPS\_FARMED

```ts
readonly CUSTOM_CROPS_FARMED: "Custom Crops Farmed" = 'Custom Crops Farmed';
```

#### oneblock.MOBS\_KILLED

```ts
readonly MOBS_KILLED: "Mobs Killed" = 'Mobs Killed';
```

#### oneblock.ONE\_BLOCK\_BROKEN

```ts
readonly ONE_BLOCK_BROKEN: "One Block Broken" = 'One Block Broken';
```

#### oneblock.PLAYER\_LEVEL

```ts
readonly PLAYER_LEVEL: "Player Level" = 'Player Level';
```

### opfactions

```ts
readonly opfactions: object;
```

#### Type Declaration

#### opfactions.balance

```ts
readonly balance: "Balance" = 'Balance';
```

#### opfactions.DEATHS

```ts
readonly DEATHS: "Deaths" = 'Deaths';
```

#### opfactions.HARVEST\_SUGAR\_CANE

```ts
readonly HARVEST_SUGAR_CANE: "Harvest Sugar Cane" = 'Harvest Sugar Cane';
```

#### opfactions.HIGHEST\_KILLSTREAK

```ts
readonly HIGHEST_KILLSTREAK: "Highest Killstreak" = 'Highest Killstreak';
```

#### opfactions.kills

```ts
readonly kills: "Kills" = 'Kills';
```

#### opfactions.MOBS\_KILLED

```ts
readonly MOBS_KILLED: "Mobs Killed" = 'Mobs Killed';
```

#### opfactions.PLAYER\_LEVEL

```ts
readonly PLAYER_LEVEL: "Player Level" = 'Player Level';
```

#### opfactions.TOTAL\_KOTHS\_WON

```ts
readonly TOTAL_KOTHS_WON: "Total koths won" = 'Total koths won';
```

### oplifesteal

```ts
readonly oplifesteal: object;
```

#### Type Declaration

#### oplifesteal.balance

```ts
readonly balance: "Balance" = 'Balance';
```

#### oplifesteal.BLOCKS\_BROKEN

```ts
readonly BLOCKS_BROKEN: "Blocks Broken" = 'Blocks Broken';
```

#### oplifesteal.BLOCKS\_PLACED

```ts
readonly BLOCKS_PLACED: "Blocks Placed" = 'Blocks Placed';
```

#### oplifesteal.DEATHS

```ts
readonly DEATHS: "Deaths" = 'Deaths';
```

#### oplifesteal.HIGHEST\_KILLSTREAK

```ts
readonly HIGHEST_KILLSTREAK: "Highest Killstreak" = 'Highest Killstreak';
```

#### oplifesteal.kills

```ts
readonly kills: "Kills" = 'Kills';
```

#### oplifesteal.MOBS\_KILLED

```ts
readonly MOBS_KILLED: "Mobs Killed" = 'Mobs Killed';
```

#### oplifesteal.PLAYER\_LEVEL

```ts
readonly PLAYER_LEVEL: "Player Level" = 'Player Level';
```

### opprison

```ts
readonly opprison: object;
```

#### Type Declaration

#### opprison.kills

```ts
readonly kills: null = null;
```

#### opprison.PRISON\_ASCENSION

```ts
readonly PRISON_ASCENSION: "Ascension" = 'Ascension';
```

#### opprison.PRISON\_BEACON\_BALANCE

```ts
readonly PRISON_BEACON_BALANCE: "Beacons" = 'Beacons';
```

#### opprison.PRISON\_BLOCKS\_BROKEN

```ts
readonly PRISON_BLOCKS_BROKEN: "Blocks Broken" = 'Blocks Broken';
```

#### opprison.PRISON\_PRESTIGE

```ts
readonly PRISON_PRESTIGE: "Prestige" = 'Prestige';
```

#### opprison.PRISON\_RAW\_BLOCKS\_BROKEN

```ts
readonly PRISON_RAW_BLOCKS_BROKEN: "Raw Blocks Broken" = 'Raw Blocks Broken';
```

#### opprison.PRISON\_TOKEN\_BALANCE

```ts
readonly PRISON_TOKEN_BALANCE: "Tokens" = 'Tokens';
```

### opskyblock

```ts
readonly opskyblock: object;
```

#### Type Declaration

#### opskyblock.ADVENTURER\_SKILL\_LEVEL

```ts
readonly ADVENTURER_SKILL_LEVEL: "Adventurer Skill Level" = 'Adventurer Skill Level';
```

#### opskyblock.ALCHEMIST\_SKILL\_LEVEL

```ts
readonly ALCHEMIST_SKILL_LEVEL: "Alchemist Skill Level" = 'Alchemist Skill Level';
```

#### opskyblock.ARCHERY\_SKILL\_LEVEL

```ts
readonly ARCHERY_SKILL_LEVEL: "Archery Skill Level" = 'Archery Skill Level';
```

#### opskyblock.AXES\_SKILL\_LEVEL

```ts
readonly AXES_SKILL_LEVEL: "Axes Skill Level" = 'Axes Skill Level';
```

#### opskyblock.balance

```ts
readonly balance: "Balance" = 'Balance';
```

#### opskyblock.BANKER\_SKILL\_LEVEL

```ts
readonly BANKER_SKILL_LEVEL: "Banker Skill Level" = 'Banker Skill Level';
```

#### opskyblock.FARMER\_SKILL\_LEVEL

```ts
readonly FARMER_SKILL_LEVEL: "Farmer Skill Level" = 'Farmer Skill Level';
```

#### opskyblock.kills

```ts
readonly kills: null = null;
```

#### opskyblock.LUCKY\_SKILL\_LEVEL

```ts
readonly LUCKY_SKILL_LEVEL: "Lucky Skill Level" = 'Lucky Skill Level';
```

#### opskyblock.MINER\_SKILL\_LEVEL

```ts
readonly MINER_SKILL_LEVEL: "Miner Skill Level" = 'Miner Skill Level';
```

#### opskyblock.PLAYER\_LEVEL

```ts
readonly PLAYER_LEVEL: "Player Level" = 'Player Level';
```

#### opskyblock.SKILL\_LEVEL

```ts
readonly SKILL_LEVEL: "Skill Level" = 'Skill Level';
```

#### opskyblock.Souls

```ts
readonly Souls: "Souls" = 'Souls';
```

#### opskyblock.SPECIAL\_ORES\_MINED

```ts
readonly SPECIAL_ORES_MINED: "Special Ores Mined" = 'Special Ores Mined';
```

#### opskyblock.WIZARD\_SKILL\_LEVEL

```ts
readonly WIZARD_SKILL_LEVEL: "Wizard Skill Level" = 'Wizard Skill Level';
```

### pillars

```ts
readonly pillars: object;
```

#### Type Declaration

#### pillars.kills

```ts
readonly kills: "Kills" = 'Kills';
```

#### pillars.played

```ts
readonly played: "Games played" = 'Games played';
```

#### pillars.wins

```ts
readonly wins: "Wins" = 'Wins';
```

### skymines

```ts
readonly skymines: object;
```

#### Type Declaration

#### skymines.balance

```ts
readonly balance: "Balance" = 'Balance';
```

#### skymines.BLOCKS\_MINED

```ts
readonly BLOCKS_MINED: "Blocks Mined" = 'Blocks Mined';
```

#### skymines.BOSSES\_KILLED

```ts
readonly BOSSES_KILLED: "Bosses Killed" = 'Bosses Killed';
```

#### skymines.DEATHS

```ts
readonly DEATHS: "Deaths" = 'Deaths';
```

#### skymines.HIGHEST\_KILLSTREAK

```ts
readonly HIGHEST_KILLSTREAK: "Highest Killstreak" = 'Highest Killstreak';
```

#### skymines.kills

```ts
readonly kills: "Kills" = 'Kills';
```

#### skymines.PLAYER\_LEVEL

```ts
readonly PLAYER_LEVEL: "Player Level" = 'Player Level';
```

### skypvp

```ts
readonly skypvp: object;
```

#### Type Declaration

#### skypvp.balance

```ts
readonly balance: "Balance" = 'Balance';
```

#### skypvp.CURRENT\_KILLSTREAK

```ts
readonly CURRENT_KILLSTREAK: "Current Killstreak" = 'Current Killstreak';
```

#### skypvp.DEATHS

```ts
readonly DEATHS: "Deaths" = 'Deaths';
```

#### skypvp.HIGHEST\_KILLSTREAK

```ts
readonly HIGHEST_KILLSTREAK: "Highest Killstreak" = 'Highest Killstreak';
```

#### skypvp.kills

```ts
readonly kills: "Kills" = 'Kills';
```

#### skypvp.LUCKY\_CRATES\_OPENED

```ts
readonly LUCKY_CRATES_OPENED: "Lucky Crates Opened" = 'Lucky Crates Opened';
```

#### skypvp.RANK\_RATING

```ts
readonly RANK_RATING: "Rank Rating" = 'Rank Rating';
```

### survival

```ts
readonly survival: object;
```

#### Type Declaration

#### survival.balance

```ts
readonly balance: "Balance" = 'Balance';
```

#### survival.EXP\_COLLECTED

```ts
readonly EXP_COLLECTED: "EXP Collected" = 'EXP Collected';
```

#### survival.MOBS\_KILLED

```ts
readonly MOBS_KILLED: "Mobs Killed" = 'Mobs Killed';
```

#### survival.PLAYER\_LEVEL

```ts
readonly PLAYER_LEVEL: "Player Level" = 'Player Level';
```

### unrankedpractice

```ts
readonly unrankedpractice: object;
```

#### Type Declaration

#### unrankedpractice.HIGHEST\_WIN\_STREAK

```ts
readonly HIGHEST_WIN_STREAK: "Highest winstreak reached" = 'Highest winstreak reached';
```

#### unrankedpractice.kills

```ts
readonly kills: "Kills" = 'Kills';
```

#### unrankedpractice.LOSSES

```ts
readonly LOSSES: "Losses" = 'Losses';
```

#### unrankedpractice.MELEE\_DEALT

```ts
readonly MELEE_DEALT: "Hits dealt" = 'Hits dealt';
```

#### unrankedpractice.MELEE\_TAKEN

```ts
readonly MELEE_TAKEN: "Hits taken" = 'Hits taken';
```

#### unrankedpractice.played

```ts
readonly played: "Games played" = 'Games played';
```

#### unrankedpractice.VOID\_KILLS

```ts
readonly VOID_KILLS: "Void kills" = 'Void kills';
```

#### unrankedpractice.wins

```ts
readonly wins: "Wins" = 'Wins';
```
